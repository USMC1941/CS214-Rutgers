#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "stuff.h"

int main(int argc, char ** argv)
{

	printf(" other things %d\n", values(6));

	return 0;
}
