int values(int num)
{
	return num;
}
