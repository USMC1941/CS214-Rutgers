#ifndef STUFF_H
#define STUFF_H


#define THING 3

int values(int num);


#endif
