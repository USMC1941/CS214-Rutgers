#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "sortingkey.h"
#include "record.h"
#include "helper.h"
#include "recordarray.h"


/*
Initializes the record array
Return:
	1 means failed
	0 means OK
*/
int initializeRecordArray(RecordArray* pRecordArray, int initialCapacity) {
	int outcome = FAILURE;			// 1 means failed
	//
	if (pRecordArray != NULL) {
		pRecordArray->pRaw					= NULL;					// raw data read from file
		pRecordArray->recPtrArray			= NULL;					// Array of Record pointer
		pRecordArray->recDataArray		= NULL;					// Array of Record pointer
		pRecordArray->iCapacity				= 0;							// Total capacity
		pRecordArray->iSize						= 0;							// Current size
		//
		//pRecordArray->sKI;
		pRecordArray->sKI.index				= -1;
		//
		pRecordArray->next						= NULL;
		//
		if (initialCapacity>0) {
			pRecordArray->recDataArray = (Record*)malloc(sizeof(Record) * initialCapacity);
			//
			if (pRecordArray->recDataArray) {
				pRecordArray->iCapacity = initialCapacity;
				outcome = SUCCESS;
			}
		}
		//
	}
	//
	return outcome;
}



/*
Inserts one record into the RecordArray
*/
Record* getOneRecord(RecordArray* pRecordArray) {
	Record* pRec = NULL;

	// Check inputs
	if (pRecordArray == NULL) {
	}
	else {
		if (pRecordArray->iCapacity > pRecordArray->iSize) {										// Has enough space to insert
		}
		else {
			int newSize = pRecordArray->iCapacity * 1.5;
			pRecordArray->recDataArray = (Record*)realloc(pRecordArray->recDataArray, sizeof(Record) * newSize);
			pRecordArray->iCapacity = newSize;
		}
		//
		pRec = (pRecordArray->recDataArray + pRecordArray->iSize);
		pRecordArray->iSize++;
	}
	//
	return pRec;
}


/**
 * Set pointer array which points to data Array
 * @param pRecordArray Input RecordArray
 */
void setPtrArray(RecordArray* pRecordArray) {
	if (pRecordArray != NULL) {
		pRecordArray->recPtrArray = (Record**)malloc(sizeof(Record*) * (pRecordArray->iSize));
		int i;
		for (i = 0; i < pRecordArray->iSize; i++) {
			*(pRecordArray->recPtrArray + i) = (pRecordArray->recDataArray + i);
		}
	}
}



/**
 * Resize pointer Array
 * @param pRecordArray RecordArray
 * @param size         Desired size
 */
void resizePtrArray(RecordArray* pRecordArray, int size) {
	if (pRecordArray) {
		if (pRecordArray->recPtrArray) {
			if (pRecordArray->iCapacity < size) {
				pRecordArray->recPtrArray = (Record**)realloc(pRecordArray->recPtrArray, sizeof(Record*) * size);
				pRecordArray->iCapacity = size;
			}
		}
		else {
			pRecordArray->recPtrArray = (Record**)malloc(sizeof(Record*) * size);
			pRecordArray->iCapacity = size;
		}
	}
}


/*
Frees the RecordArray
*/
void cleanRecordArray(RecordArray* pRecordArray) {
	if (pRecordArray != NULL) {
		if (pRecordArray->pRaw) {
			free(pRecordArray->pRaw);
			pRecordArray->pRaw = NULL;
		}
		//
		if (pRecordArray->recPtrArray) {
			free(pRecordArray->recPtrArray);
			pRecordArray->recPtrArray = NULL;
		}
		//
		if (pRecordArray->recDataArray) {
			free(pRecordArray->recDataArray);
			pRecordArray->recDataArray = NULL;
		}
	}
}
