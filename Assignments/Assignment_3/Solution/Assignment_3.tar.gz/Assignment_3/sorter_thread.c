#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <pthread.h>

#include "global.h"
#include "helper.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "sorter_thread.h"
#include "mergesort.h"
#include "csvsorter.h"
#include "tokenizer.h"
#include "linked_list.h"


// These 3 global variables will be accessed by all threads. They need to be protected
volatile int 		runningThreadCount 	= 0;							// Number of threads running
volatile int 		totalThreadCount 		= 0;							// Total Number of threads running
PRecordArray 	pRecordArray 			= NULL;				// Linked list holding sorted .csv files



PFUNC_COMPARE_DATA g_pFuncCompare = compare;



pthread_mutex_t 		data_mutex 	= PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t 		data_cond 	= PTHREAD_COND_INITIALIZER;
pthread_attr_t 			attr;




int main(int argc, char* argv[]) {
	// Check for right number of inputs
	if (argc == 3 || argc == 5 || argc == 7) {																			// for 1 or 2 or 3 parameters and there options
		// Good
	}
	else {
		fprintf(stderr, "Usage Sorting: sorter -c sorting_key_field.\n");
		fprintf(stderr, "Usage Searching Directory: sorter -c sorting_key_field -d thisdir.\n");
		fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
		fprintf(stderr, "Invalid number of parameters: %d!\n", argc);
		return 1;
	}

	// Parameters
	char* pSortingKey = NULL;		// -c
	char* pInDir			=	NULL;		// -d
	char* pOutDir		= NULL;		// -o

	// Find parameters
	int i;
	for (i = 1; i < argc; i = i + 2) {
		char* pOption = argv[i];
		//
		if (strcmp(pOption, "-c") == 0) {																							// sortimg key
			if (pSortingKey == NULL) {
				pSortingKey = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
				return 1;
			}
		}
		else if (strcmp(pOption, "-d") == 0) {
			if (pInDir == NULL) {
				pInDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
				return 1;
			}
		}
		else if (strcmp(pOption, "-o") == 0) {
			if (pOutDir == NULL) {
				pOutDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
				return 1;
			}
		}
		else {
			fprintf(stderr, "Usage Sorting: sorter -c sorting_key_field.\n");
			fprintf(stderr, "Usage Searching Directory: sorter -c sorting_key_field -d thisdir.\n");
			fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
			fprintf(stderr, "Invalid parameter options %s!\n", pOption);
			return 1;
		}
	}

	if (pSortingKey == NULL) {
		fprintf(stderr, "Usage Sorting: sorter -c sorting_key_field.\n");
		fprintf(stderr, "Usage Searching Directory: sorter -c sorting_key_field -d thisdir.\n");
		fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
		fprintf(stderr, "Mandatory Parameters: sorting_key_field not present!\n");
		return 1;
	}
	
	// Default
	if (pInDir == NULL) {
		pInDir = ".";
	}

	// Create Directory if not exits
	if (pOutDir != NULL && strcmp(pOutDir, ".") != 0) {
	   mkdir(pOutDir, 0700);
	}
	
	//int pthread_attr: thread attr is detached. So no need to wait for the threads
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	// This loop is for Indir and all subfolders
	SortingParam* pSortingParam = (SortingParam*)malloc(sizeof(SortingParam));
	setSortingParam(NULL, pInDir, NULL, pSortingKey, pSortingParam);
	
	// Handleing parent directory
	handleFileOrDir(pSortingParam);

	// Starting output sorted records to file
	PRecordArray 	pRecordArrayOutput 	= NULL;				// Linked list holding sorted .csv files fro output
	char* pHeader = NULL;
	
	RecordArray recordArrays[SORT_ARRAY_SIZE_ADD];
	RecordArray* pTempRecordArrays[SORT_ARRAY_SIZE_ADD];
	{	int idx;
		for (idx=0; idx<SORT_ARRAY_SIZE_ADD; idx++) {
			initializeRecordArray(&recordArrays[idx], 0);
			pTempRecordArrays[idx] = &recordArrays[idx];
		}
	}

	// Main thread finish handling input directory by creating threads to handle subdirectories and files
	int runningThreadCountNow = 0;
	while (TRUE) {
		PRecordArray pRecordArrayNow = NULL;
		//
		pthread_mutex_lock(&data_mutex);										// Get lock first
		//
		while (!(pRecordArray || runningThreadCount == 0)) {				// Condition not need to wait: If output need to be processed or no more running threads to wait for 
			pthread_cond_wait(&data_cond, &data_mutex);
		}
		//
		runningThreadCountNow = runningThreadCount;						// Create a copy of runningThreadCount
		if (pRecordArray) {
			swap(&pRecordArray, &pRecordArrayNow); 							// Retrieve output from linked list then reset it.
		}
		else {
			pRecordArrayNow = NULL;
		}
		//
		pthread_mutex_unlock(&data_mutex);										// Get lock first
		//
		// Do printing without need for lock
		if (pRecordArrayNow) {
			int count = 0;
			PRecordArray pOne = removeOne(&pRecordArrayNow);
			while (pOne) {
				if (insertOne(&pRecordArrayOutput, pOne)==SUCCESS) {
					if (!pHeader) {
						pHeader = pOne->pRaw;
					}
					//
					count++;
				};
				//
				pOne = removeOne(&pRecordArrayNow);
			}
			//
			sortAndMergeFiles(pRecordArrayOutput, pTempRecordArrays, count);
		}
		//
		if (runningThreadCountNow == 0) {
			break;
		}
	}
	//
	// Create output file name
	char outFullFileName[PATH_MAX + NAME_MAX + 1];
	strcpy(outFullFileName, "");
	if (pOutDir != NULL) {
		strcat(outFullFileName, pOutDir);
		strcat(outFullFileName, "/");
	}
	strcat(outFullFileName, "AllFiles-sorted-");
	strcat(outFullFileName, pSortingKey);
	strcat(outFullFileName, ".csv");
	//
	FILE *file = fopen(outFullFileName, "w");
	if (file != NULL) {
		writeRecordArrayToFile(pHeader, pTempRecordArrays[OUT_IDX], file);
		fclose(file);
	}
	else {
		fprintf(stderr, "Could not open file for output %s\n", strerror(errno));
	}
	//
	cleanUpRecordArray(&pRecordArrayOutput);
	//
	{	int idx;
		for (idx=0; idx<SORT_ARRAY_SIZE_ADD; idx++) {
			cleanRecordArray(&recordArrays[idx]);
		}
	}
	//
	return 0;
}






/**
 * Thread function to handle one file or one directory
 * @param  input     				Pointer to SortingParam
 * @param  return  					Nothing
 */
void* threadFunc(void* input) {
	RecordArray* pRcdArray = handleFileOrDir(input);				// Handle a file or directory
	//
	// Thread is about to exit. put output to global linked-list and signal main thread
	pthread_mutex_lock(&data_mutex);								// Get lock first
	//
	runningThreadCount--;														// Since this thread is exiting, reduce runningThreadCount by 1
	//
	if (pRcdArray) {																// Put sorted recordArray into linked list for main thread to sort (with other files) and output
		insertOne(&pRecordArray, pRcdArray);
	}
	//
	pthread_cond_signal(&data_cond);									// Only main thread are waiting
	//
	pthread_mutex_unlock(&data_mutex);								// Release lock
	//
	return NULL;
}




/**
 * Function to handle one file or one directory
 * @param  input     				Pointer to SortingParam
 * @param  return  					Sorted record array for a file. Null for directory
 */
RecordArray* handleFileOrDir(void* input) {
	int  childThreadCount		= 0;
	BUFFER buf;																																				// For holding metadata
	initBuffer(&(buf), 4096);
	
	// Metadata
	sprintf(buf.data, "Initial TID: %lu\nTIDS of all child threads: ", pthread_self());												// Metadata to output to stdout
	
	SortingParam* pSortingParam = (SortingParam*)input;
	//
	RecordArray* pRcdArray = NULL;
	if (pSortingParam->isFile) {																														// Handle a file
		pRcdArray = doSorting(pSortingParam);																								// Read the file and sort it
	}
	else {																																						// Handle directory
		// Loop through all items in the folder
		DIR *dir = NULL;
		struct dirent *entry;
		//
		if (!(dir = opendir(pSortingParam->inFullFileName))) {																			// Coudl not open directory. Do nothing
			fprintf(stderr, "Could not open directory %s: %s\n", pSortingParam->inFullFileName, strerror(errno));
		}
		else {
			while ((entry = readdir(dir)) != NULL) {
				if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {						// Current or parent directory
					// Ignore
				}
				else if (entry->d_type == DT_DIR) {																					// Directory
					SortingParam* pSortingParamChild = (SortingParam*)malloc(sizeof(SortingParam));		// File or directory info for child thread
					setSortingParam(pSortingParam->inFullFileName, entry->d_name, NULL, pSortingParam->sortingKeys, pSortingParamChild);
					//
					pthread_mutex_lock(&data_mutex);
					runningThreadCount++;
					totalThreadCount++;
					pthread_mutex_unlock(&data_mutex);
					//
					pthread_t thread_id;
					pthread_create(&thread_id, &attr, threadFunc, pSortingParamChild);
					childThreadCount++;
					sprintf(getBufForAppend(&buf, 32), "%lu,", thread_id);
				}
				else {																																	// File: if (entry->d_type != DT_DIR)
					int lenName = strlen(entry->d_name);
					if (lenName > 4 && strcicmp(entry->d_name + lenName - 4, ".csv") == 0) {					// Check if file is .csv
						SortingParam* pSortingParamChild = (SortingParam*)malloc(sizeof(SortingParam));
						setSortingParam(pSortingParam->inFullFileName, NULL, entry->d_name, pSortingParam->sortingKeys, pSortingParamChild);
						//
						pthread_mutex_lock(&data_mutex);
						runningThreadCount++;
						totalThreadCount++;
						pthread_mutex_unlock(&data_mutex);
						//
						pthread_t thread_id;
						pthread_create(&thread_id, &attr, threadFunc, pSortingParamChild);
						childThreadCount++;
						sprintf(getBufForAppend(&buf, 32), "%lu,", thread_id);
					}
					else {
						// Not a csv file. Ignore
					}
				}
			}
		}
		//
		if (dir) {
			closedir(dir);
		}
	}
	//
	sprintf(getBufForAppend(&buf, 64), "\nTotal number of threads: %d\n\n", childThreadCount);
	//
	printf(buf.data, "%s", buf.data);
	//
	freeBuffer(&buf);																															// Not needed after metadata printed
	free(pSortingParam);																													// mallco be parent. free by child.
	//
	return pRcdArray;
}




/**
 * Merge sorted RecordArrays into one sorted 
 * @param  pHead     				Linked List of RecordArray
 * @param  ppRecordArray 		Working memory and output (merged) recordarray
 * @param  count					Number of RecordArray in the list to merge
 * 128 working memory is used to merge record array of roughly the same size.
 * This is trying to avoid extra copying when merged large record array with small one.
 */
void sortAndMergeFiles(PRecordArray pHead, RecordArray** ppRecordArray, int count) {
	PRecordArray pOne = NULL;
	PRecordArray pTwo = NULL;
	//
	// Merge input RecordArray from Linked_List into working memory
	if (count == 1) {																													//Merge one recordarray
		pOne = pHead;
		//Merge pOnw and OUT_IDX to TMP_IDX
		mergeTwo(pOne, ppRecordArray[OUT_IDX], ppRecordArray[TMP_IDX]);
		//Swap OUT_IDX and IMP_IDX
		RecordArray* pTemp = ppRecordArray[OUT_IDX];
		ppRecordArray[OUT_IDX] = ppRecordArray[TMP_IDX];
		ppRecordArray[TMP_IDX] = pTemp;
	}
	else {																																	// more than one recordarray
		int i, j;
		for (i = 0; i < count; i = i+2) {																							// merge two at a time
			j = (i/2) % SORT_ARRAY_SIZE;
			//
			if (i==0) {
				pOne = pHead;
			}
			else {
				pOne = pTwo->next;
			}
			pTwo = pOne->next;
			//
			if (pTwo != NULL) {																										// have two
				if (ppRecordArray[j]->iSize==0) {																			// target working memory is empty
					//pOne + pTwo -> j
					mergeTwo(pOne, pTwo, ppRecordArray[j]);
				}
				else {																														// target working memory already has recordarray
					//pOne + pTwo -> TMP
					mergeTwo(pOne, pTwo, ppRecordArray[TMP_IDX]);
					// j + TMP -> TMP_1
					mergeTwo(ppRecordArray[TMP_IDX], ppRecordArray[j], ppRecordArray[TMP_1_IDX]);
					//Swap j and IMP_1_IDX
					RecordArray* pTemp = ppRecordArray[j];
					ppRecordArray[j] = ppRecordArray[TMP_1_IDX];
					ppRecordArray[TMP_1_IDX] = pTemp;
				}
			}
			else {																															// have only one
				j = 0;																														// merge into head of the working memory
				if (ppRecordArray[j]->iSize==0) {																			// never happen as count =1 will not come here.
					//never here
					printf("Never here\n");
					//
					//pOne + j -> TMP
					mergeTwo(pOne, ppRecordArray[j], ppRecordArray[TMP_IDX]);							// do it anyway
					//Swap j and IMP_IDX
					RecordArray* pTemp = ppRecordArray[j];
					ppRecordArray[j] = ppRecordArray[TMP_IDX];
					ppRecordArray[TMP_IDX] = pTemp;
				}
				else {																														// target already have recordarray
					//pOne + j -> TMP
					mergeTwo(pOne, ppRecordArray[j], ppRecordArray[TMP_IDX]);
					//Swap j and IMP_IDX
					RecordArray* pTemp = ppRecordArray[j];
					ppRecordArray[j] = ppRecordArray[TMP_IDX];
					ppRecordArray[TMP_IDX] = pTemp;
				}
			}
		}
		//
		// Merge record arrays in working memory into one
		while (TRUE) {
			int 					changed 	= 0;
			PRecordArray 	p1 			= NULL;
			PRecordArray 	p2 			= NULL;
			for (i=0; i<SORT_ARRAY_SIZE; i=i+2) {
				j = i/2;
				//
				p1 = ppRecordArray[i];
				p2 = ppRecordArray[i+1];
				//
				if (p1->iSize>0 && p2->iSize>0) {
					//pOne + j -> TMP
					mergeTwo(p1, p2, ppRecordArray[TMP_IDX]);
					//Swap j and IMP_IDX
					RecordArray* pTemp = ppRecordArray[j];
					ppRecordArray[j] = ppRecordArray[TMP_IDX];
					ppRecordArray[TMP_IDX] = pTemp;
					//
					//
					changed = 1;
				}
				else if (p1->iSize>0 && p2->iSize==0) {
					if (i==0) {
						//do nothing
					}
					else {
						RecordArray* pTemp = ppRecordArray[j];
						ppRecordArray[j] = ppRecordArray[i];
						ppRecordArray[i] = pTemp;
						//
						changed = 1;
					}
				}
				else {
					break;
				}
			}
			//
			if (changed==0) {
				break;
			}
		}
		//
		//
 		// Merge one recordarray into output
		//OUT_IDX + 0 -> TMP
		mergeTwo(ppRecordArray[OUT_IDX], ppRecordArray[0], ppRecordArray[TMP_IDX]);
		//Swap OUT_IDX and IMP_IDX
		RecordArray* pTemp = ppRecordArray[OUT_IDX];
		ppRecordArray[OUT_IDX] = ppRecordArray[TMP_IDX];
		ppRecordArray[TMP_IDX] = pTemp;
	}
}





/**
 * Merge two sorted RecordArrays into one sorted 
 * @param  p1     		First record array
 * @param  p2 			Second record arrasy
 * @param  pMerged    Merged recordarray
 */
void mergeTwo(PRecordArray p1, PRecordArray p2, PRecordArray pMerged) {
	resizePtrArray(pMerged, p1->iSize + p2->iSize);
	merge((void**)p1->recPtrArray, p1->iSize, (void**)p2->recPtrArray, p2->iSize, (void**)pMerged->recPtrArray, g_pFuncCompare);
	pMerged->iSize = p1->iSize + p2->iSize;
	p1->iSize = 0;
	p2->iSize = 0;
}

 




/**
 * Writes the data from the RecordArray into file
 * @param  pHeader      		Field name line
 * @param  pRecordArray	Array of records
 * @param  file  					Opened output file
 * @return              				Success or failure
 */
int writeRecordArrayToFile(char* header, RecordArray* pRecordArray, FILE *file) {
	int outcome = FAILURE;
	//
	if (file != NULL) {
		fprintf(file, "%s\n", header);																														// Print header line
		//
		// Print all records
		int i;
		for (i = 0; i < pRecordArray->iSize; i++) {
			*((*(pRecordArray->recPtrArray + i))->pSKeyTerm) = (*(pRecordArray->recPtrArray + i))->chHold;	// Put back the char set to '\0' for sorting key
			//
			fprintf(file, "%s\n", (*(pRecordArray->recPtrArray + i))->recordData);													// Print Records in a loop
		}
		//
		outcome = SUCCESS;
	}
	else {
		fprintf(stderr, "Error: %s\n", strerror(errno));																							// Could not open file for writing
	}
	//
	return outcome;
}
