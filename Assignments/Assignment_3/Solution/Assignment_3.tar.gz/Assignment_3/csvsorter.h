#ifndef CSVSORTER_H
#define CSVSORTER_H


// Structure passed inside the thread function
typedef struct SortingParam {
	char inFullFileName[3 * PATH_MAX + NAME_MAX + 1];	// Full file name including path
	char sortingKeys[MAX_KEY_LENGTH];						// Sorting keys
	int 	isFile;													// Is file or directory
} SortingParam;


/**
 * Perform sorting with sortingKey
 * @param inParentPath    Parent path of inPath
 * @param inPath          Input path name
 * @param inName          Input file name
 * @param sortingKeyInput Key for sorting
 * @param pSortingParam   SortingParam structure
 */
void setSortingParam(const char* inParentPath, const char* inPath, const char* inName, const char* sortingKeyInput, SortingParam* pSortingParam);


/**
 * Performs sorting algorithm
 * @param  pSortingParam SortingParam structure
 * @return               Sorted RecordArray
 */
RecordArray* doSorting(SortingParam* pSortingParam);



#endif
