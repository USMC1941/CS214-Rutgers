#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "global.h"
#include "helper.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "mergesort.h"
#include "csvsorter.h"
#include "tokenizer.h"


/**
 * Performs sorting algorithm
 * @param  pSortingParam SortingParam structure
 * @return               Sorted RecordArray
 */
RecordArray* doSorting(SortingParam* pSortingParam) {
	PFUNC_COMPARE_DATA pFuncCompare = compare;
	
	struct stat file_stats;

	// To hold record array
	RecordArray* pRcdArray = (RecordArray*)malloc(sizeof(RecordArray));

	if (!stat(pSortingParam->inFullFileName, &file_stats)) {
		//printf("%u bytes\n", (unsigned int)file_stats.st_size);
	}
	else {
		fprintf(stderr, "Error: %s\n", strerror(errno));
	}

	FILE *file = fopen(pSortingParam->inFullFileName, "r");

	BUFFER buf;											// For holding the header line
	initBuffer(&(buf), 0);						// Buffer for holding header line

	if (file == NULL) {
		fprintf(stderr, "Error: %s\n", strerror(errno));
	}
	else if (initializeRecordArray(pRcdArray, SIZE_INITIAL) != SUCCESS) {
		cleanRecordArray(pRcdArray);
		free(pRcdArray);
		pRcdArray = NULL;
		//
		fprintf(stderr, "Could not parse sorting key\n");
	}
	else {
		unsigned int lenRemain = file_stats.st_size + 1 + 2;											// 1 for NULL. 1 for \n. 1 for next read which will fail.
		pRcdArray->pRaw = (char*)malloc(sizeof(char) * (lenRemain + 1 + 2));
		char* pRemain = pRcdArray->pRaw;
		// Read the header and get the index for the sorting key

		if (fgets(pRemain, lenRemain, file) > 0 ) {
			int len = stripOffNewline(pRemain);
			//
			resizeBuffer(&buf, len + 1);
			strcpy(buf.data, pRemain);						// Keep an copy of the header line before tokenize
			//
			pRemain = pRemain + len + 1;
			lenRemain = lenRemain - len - 1;
			//
			if (getSortingKeyIndexFromHeaderLine(buf.data, pSortingParam->sortingKeys, &(pRcdArray->sKI))) {
				cleanRecordArray(pRcdArray);
				free(pRcdArray);
				pRcdArray = NULL;
				//
				fprintf(stderr, "Could not parse sorting key\n");
			}
			else {
				// Read data line by line. Creates record and put them into array
				//while (getline(&(readBuf.data), &(readBuf.length), file) > 0) {
				while (fgets(pRemain, lenRemain, file) > 0) {
					int len = stripOffNewline(pRemain);
					//
					resizeBuffer(&buf, len + 1);
					strcpy(buf.data, pRemain);						// Keep an copy of the header line before tokenize

					Record* pRecord = getOneRecord(pRcdArray);

					Record* pOut = setRecordData(pRecord, pRemain, buf.data, &(pRcdArray->sKI));

					if (!pOut) {
						fprintf(stderr, "Could not create record\n");
					}
					//
					pRemain = pRemain + len + 1;
					lenRemain = lenRemain - len - 1;
				}
				//
				setPtrArray(pRcdArray);
				//
				mergeSort((void**)(pRcdArray->recPtrArray), 0, pRcdArray->iSize - 1, pFuncCompare);
			}
		}
	}

	
	if (file != NULL) {
		fclose(file);
	}

	//Free buffer
	freeBuffer(&buf);

	// Return
	return pRcdArray;
}


/**
 * Perform sorting with sortingKey
 * @param inParentPath    Parent path of inPath
 * @param inPath          Input path name
 * @param inName          Input file name
 * @param sortingKeyInput Key for sorting
 * @param pSortingParam   SortingParam structure
 */
void setSortingParam(const char* inParentPath, const char* inPath, const char* inName, const char* sortingKeyInput, SortingParam* pSortingParam) {
	strcpy(pSortingParam->sortingKeys, sortingKeyInput);
	//
	strcpy(pSortingParam->inFullFileName, "");												// Current Directory
	//
	int emptyParentPath 	= inParentPath == NULL || strlen(inParentPath) == 0;
	int emptyPath 			= inPath == NULL || strlen(inPath) == 0;
	int emptyName 			= inName == NULL || strlen(inName) == 0;
	//
	if (emptyParentPath && emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, ".");
		pSortingParam->isFile = FALSE;
	}
	else if (emptyParentPath && emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (emptyParentPath && !emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inPath);
		pSortingParam->isFile = FALSE;
	}
	else if (emptyParentPath && !emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (!emptyParentPath && emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		pSortingParam->isFile = FALSE;
	}
	else if (!emptyParentPath && emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (!emptyParentPath && !emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inPath);
		pSortingParam->isFile = FALSE;
	}
	else if (!emptyParentPath && !emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
}