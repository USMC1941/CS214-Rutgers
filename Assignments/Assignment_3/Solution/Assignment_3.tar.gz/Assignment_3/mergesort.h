#ifndef MERGESORT_H
#define MERGESORT_H


/*
Pointer type to function that compares two items
*/
typedef int (*PFUNC_COMPARE_DATA)(void* pData1, void* pData2);


/*
 Merges two subarrays of arr[].
 First subarray is arr[l..m]
 Second subarray is arr[m+1..r]
*/
void merge(void* arr1[], int n1, void* arr2[], int n2, void* arr[], PFUNC_COMPARE_DATA pFuncCompare);


/*
Sorts the array

l is for left index and r is right index of the sub-array of arr to be sorted
*/
void mergeSort(void* arr[], int l, int r, PFUNC_COMPARE_DATA pFuncCompare);


#endif