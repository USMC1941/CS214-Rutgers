#ifndef SORTINGKEY_H
#define SORTINGKEY_H


// Index for the sortingkey
typedef struct SKeyIndex {
	int index;											// (index)th field to sort. First field is 0
} SKeyIndex;


/*
Gets the index for the sortingkey from the Header Line
*/
int getSortingKeyIndexFromHeaderLine(char* input, char* key, SKeyIndex* pSKI);


#endif