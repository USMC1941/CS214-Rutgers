#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include "global.h"
#include "sortingkey.h"
#include "record.h"
#include "tokenizer.h"
#include "helper.h"


/*
Create a record. Including abstract sorting key
Also detect what data type is the key: long, float or string
*/
Record* setRecordData(Record* pRec, char* store, char* buffer, SKeyIndex* pSKI) {
	Record* pOut = NULL;
	//
	// Create the record
	if (store == NULL || *store == '\0' || buffer == NULL || *buffer == '\0' || pSKI == NULL || pRec==NULL) {
		if (pRec) {
			pRec->recordData = NULL;
			//pRec->pSKey		= NULL;
			//pRec->pSKeyTerm= NULL;
			//pRec->chHold		= '\0';
			//pRec->lKey			= 0L;
			//pRec->fKey			= 0.0;
			//pRec->idxType		= 0;
		}
	}
	else {
		pRec->recordData = store;
		//
		pOut = pRec;
	}
	//
	// Find sorting key
	if (pOut != NULL) {
		Tokenizer tokenizer;
		initTokenizer(&tokenizer, buffer, DELIMITER, DBLQUOTE);

		char* bufferStart = buffer;													// Pointer buffer will move along the string. Remember the start here.
		char* pToken;

		pToken = getNextToken(&tokenizer);

		int index = 0;
		//
		while(pSKI->index > index) {													// Go to (pSKI->index)th field, which is the sorting key
			// Key and token are not equal. Continue loop
			pToken = getNextToken(&tokenizer);
			index++;
		}
		//
		int offset;																			// Offset of the key in line
		int length;																			// Length of the key
		if (pToken == NULL) {															// No token matched. The field is NULL
			offset = strlen(pRec->recordData);										// Point to terminate char: '\0'
			length = 0;
		}
		else {
			offset = pToken - bufferStart;
			length = strlen(pToken);
		}
		//
		pRec->pSKey 		= store + offset;
		pRec->pSKeyTerm 	= store + offset + length;
		pRec->chHold 		= *pRec->pSKeyTerm;										// Remember the char at  pRec->pSKeyTerm (to be reset later)
		*pRec->pSKeyTerm 	= '\0';														// Set pRec->pSKeyTerm to NULL. Now pRec->pSKey is a proper string
		//
		pRec->lKey = 0L;																	// Try to convert to long
		pRec->fKey = 0.0f;																// Try to convert to float
		//
		char	cTemp;
		if (length > 0) {
			char* pDot = strchr(pRec->pSKey, DOT);									// Check if "." in the key
			//
			// Determine what data type it is
			// Initially assume is INDEX_TYPE_INTEGER
			// Change to INDEX_TYPE_FLOAT if encounter float number which is not INDEX_TYPE_INTEGER.
			// Change to INDEX_TYPE_STRING if encounter non-number data.
			if (!pDot && sscanf(pRec->pSKey, "%ld%c", &(pRec->lKey), &cTemp) == 1) {					// integer number
				pRec->fKey = pRec->lKey;
				pRec->idxType =INDEX_TYPE_INTEGER;
			}
			else if (pDot && sscanf(pRec->pSKey, "%f%c", &(pRec->fKey), &cTemp) == 1) {			// float number
				pRec->idxType = INDEX_TYPE_FLOAT;																			// Set the data type to INDEX_TYPE_FLOAT as there is at least one float number
			}
			else {
				pRec->idxType = INDEX_TYPE_STRING;																		// Set the data type to INDEX_TYPE_STRING as there is at least one non-number
			}
		}
		else {
			pRec->idxType = INDEX_TYPE_NULL;
		}
	}
	//
	return pOut;
}


/*
Compare keys of two records:
NULL will come first
The key could be long, float, or string type
*/
int compare(void* pData1, void* pData2) {
	int outcome;
	// 
	Record* pRecord1 = (Record*)pData1;
	Record* pRecord2 = (Record*)pData2;
	//
	int idxType1 = pRecord1->idxType;
	int idxType2 = pRecord2->idxType;
	//
	if (idxType1==INDEX_TYPE_NULL && idxType2==INDEX_TYPE_NULL) {
		outcome = 0;
	}
	else if (idxType1==INDEX_TYPE_NULL && idxType2!=INDEX_TYPE_NULL) {
		outcome = -1;
	}
	else if (idxType1!=INDEX_TYPE_NULL && idxType2==INDEX_TYPE_NULL) {
		outcome = 1;
	}
	else {
		if (idxType1== INDEX_TYPE_STRING && idxType2== INDEX_TYPE_STRING) {
			outcome = strcicmp(pRecord1->pSKey, pRecord2->pSKey);			// Not case sensitive
		}
		else if (idxType1== INDEX_TYPE_STRING && idxType2!= INDEX_TYPE_STRING) {
			outcome = 1;
		}
		else if (idxType1!= INDEX_TYPE_STRING && idxType2== INDEX_TYPE_STRING) {
			outcome = -1;
		}
		else {
			if (idxType1==INDEX_TYPE_INTEGER && idxType2==INDEX_TYPE_INTEGER) {
				long 	ldelta = pRecord1->lKey - pRecord2->lKey;
				if (ldelta == 0L) {
					outcome = 0;
				}
				else if (ldelta > 0L) {
					outcome = 1;
				}
				else {
					outcome = -1;
				}
			}
			else {
				float fdelta;
				fdelta = pRecord1->fKey - pRecord2->fKey;
				if (fdelta == 0.0) {
					outcome = 0;
				}
				else if (fdelta > 0.0) {
					outcome = 1;
				}
				else {
					outcome = -1;
				}
			}
		}
	}
	//
	return outcome;
}
