#!/bin/sh

# Sort by all keys!

make

./sorter_thread -c color -d ../testdata -o ../testout
./sorter_thread -c director_name -d ../testdata -o ../testout
./sorter_thread -c num_critic_for_reviews -d ../testdata -o ../testout
./sorter_thread -c duration -d ../testdata -o ../testout
./sorter_thread -c director_facebook_likes -d ../testdata -o ../testout
./sorter_thread -c actor_3_facebook_likes -d ../testdata -o ../testout
./sorter_thread -c actor_2_name -d ../testdata -o ../testout
./sorter_thread -c actor_1_facebook_likes -d ../testdata -o ../testout
./sorter_thread -c gross -d ../testdata -o ../testout
./sorter_thread -c genres -d ../testdata -o ../testout
./sorter_thread -c actor_1_name -d ../testdata -o ../testout
./sorter_thread -c movie_title -d ../testdata -o ../testout
./sorter_thread -c num_voted_users -d ../testdata -o ../testout
./sorter_thread -c cast_total_facebook_likes -d ../testdata -o ../testout
./sorter_thread -c actor_3_name -d ../testdata -o ../testout
./sorter_thread -c facenumber_in_poster -d ../testdata -o ../testout
./sorter_thread -c plot_keywords -d ../testdata -o ../testout
./sorter_thread -c movie_imdb_link -d ../testdata -o ../testout
./sorter_thread -c num_user_for_reviews -d ../testdata -o ../testout
./sorter_thread -c language -d ../testdata -o ../testout
./sorter_thread -c country -d ../testdata -o ../testout
./sorter_thread -c content_rating -d ../testdata -o ../testout
./sorter_thread -c budget -d ../testdata -o ../testout
./sorter_thread -c title_year -d ../testdata -o ../testout
./sorter_thread -c actor_2_facebook_likes -d ../testdata -o ../testout
./sorter_thread -c imdb_score -d ../testdata -o ../testout
./sorter_thread -c aspect_ratio -d ../testdata -o ../testout
./sorter_thread -c movie_facebook_likes -d ../testdata -o ../testout
