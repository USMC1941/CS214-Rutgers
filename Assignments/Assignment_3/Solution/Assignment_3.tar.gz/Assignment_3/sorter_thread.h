#ifndef SORTER_H
#define SORTER_H



// For combining files into output
#define SORT_ARRAY_SIZE				128
#define SORT_ARRAY_SIZE_ADD		SORT_ARRAY_SIZE + 3
#define TMP_IDX								SORT_ARRAY_SIZE
#define TMP_1_IDX							SORT_ARRAY_SIZE + 1
#define OUT_IDX								SORT_ARRAY_SIZE + 2



RecordArray* handleFileOrDir(void* input);



void* threadFunc(void* input);



void sortAndMergeFiles(PRecordArray pHead, RecordArray** ppRecordArray, int count);



void mergeTwo(PRecordArray p1, PRecordArray p2, PRecordArray pMerged);


/**
 * Writes the data from the RecordArray into file
 * @param  pHeader      Field name line
 * @param  pRecordArray Array of records
 * @param  pSKI         Sorting key information
 * @param  outFileName  Output file name
 * @return              Success or failure
 */
int writeRecordArrayToFile(char* header, RecordArray* pRecordArray, FILE *file);



#endif