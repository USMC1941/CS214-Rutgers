#ifndef SOCKET_H
#define SOCKET_H


#define SOCKET_POOL_MIN							2
#define SOCKET_POOL_MAX							128
#define SOCKET_POOL_DEFAULT					16


#define BUFFER_SIZE 								8 * 1024


#define MAXPENDING 								512    						/* Maximum outstanding connection requests */


typedef struct SOCKET {
	int sock;                        		/* Socket descriptor */
	struct sockaddr_in selfAddr; 				/* IP address of myself (either client or server) */
	struct sockaddr_in otherAddr; 			/* IP address of the other end-point */
} SOCKET;



int initClient(SOCKET* pSocket, char* pIPAddress, int iPort);


int initServer(SOCKET* pSocket, int iPort);


int socketSend(SOCKET* pSocket, char* pData, int len);


int socketRecv(SOCKET* pSocket, char* pBuffer, int len);


#endif