#ifndef PROTOCOL_H
#define PROTOCOL_H

// Message ID for 3 pairs of request and response. These numbers are picked randomly.
#define MESSAGE_TYPE_REQ_SESS_ID				56716
#define MESSAGE_TYPE_RESP_SESS_ID			1157
#define MESSAGE_TYPE_REQ_SORTING				34516
#define MESSAGE_TYPE_RESP_SORTING			3148
#define MESSAGE_TYPE_REQ_GET_RESULT			8671
#define MESSAGE_TYPE_RESP_GET_RESULT		964162


#define OUTCOME_SORTING_OK						0									// Sorting OK
#define OUTCOME_SORTING_FAILED				1									// Sorting failed. The file will not be included in output
#define OUTCOME_SORTING_NO_SESSION			2									// No match of session ID. The file will not be included in output


#define STATUS_GET_RESULT_OK					0									// Results for a session ID found
#define STATUS_GET_RESULT_NO					1									// Reslut for a session ID not found.
#define STATUS_GET_RESULT_EMPTY				2									// No sorted data

/*
Request from client to server to obtain Session ID
 */
typedef struct ReqSessionID {
	unsigned int notUsed1;																		// Filler in message to make all messages the same length
	unsigned int notUsed2;																		// Filler in message to make all messages the same length
	unsigned int notUsed3;																		// Filler in message to make all messages the same length
} ReqSessionID;


/*
Response from server to client with Session ID
 */
typedef struct RespSessionID {
	unsigned int sessionID;																		// Unique ID identifying a session
	unsigned int notUsed1;																		// Filler in message to make all messages the same length
	unsigned int notUsed2;																		// Filler in message to make all messages the same length
} RespSessionID;


/*
Request from client to server to perform sorting on file
The byte stream of the sortingKey, with len=sortingKeyLength, and the byte stream of the file, with len=dataLength, will follow this message
 */
typedef struct ReqDoSorting {
	unsigned int sessionID;																		// Unique ID identifying a session
	unsigned int sortingKeyLength;															// Length of sorting key
	unsigned int dataLength;																	// Length of data file
} ReqDoSorting;


/*
Response from server to client of the outcome of the sorting
 */
typedef struct RespDoSorting {
	unsigned int outcome;																		// Outcome of the sorting: 0: OK, >0: Failed
	unsigned int notUsed2;																		// Filler in message to make all messages the same length
	unsigned int notUsed3;																		// Filler in message to make all messages the same length
} RespDoSorting;


/*
Request from client to server to retrieve sorted data
 */
typedef struct ReqGetSorted {
	unsigned int sessionID;																		// Unique ID identifying a session
	unsigned int notUsed1;																		// Filler in message to make all messages the same length
	unsigned int notUsed2;																		// Filler in message to make all messages the same length
} ReqGetSorted;


/*
Response from server to client with sorted data
The byte stream of actual data, with len=dataLength, will follow this message.
 */
typedef struct RespGetSorted {
	unsigned int status;																			// Outcome: 0: OK, 1: Not found
	unsigned int dataLength;																	// Length of sorting result
	unsigned int notUsed;																		// Filler in message to make all messages the same length
} RespGetSorted;




/*
All possible communication between server and client
 */
typedef union Protocol {
	ReqSessionID 	reqSessionID;
	RespSessionID 	respSessionID;
	ReqDoSorting 	reqDoSorting;
	RespDoSorting 	respDoSorting;
	ReqGetSorted 	reqGetSorted;
	RespGetSorted 	respGetSorted;
} Protocol;


/*
A single message, either request or response, between client and server
 */
typedef struct Message {
	unsigned int msgType;
	Protocol protocol;
} Message;


#endif