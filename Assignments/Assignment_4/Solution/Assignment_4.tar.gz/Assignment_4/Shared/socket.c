#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>

#include "socket.h"
#include "../Shared/global.h"



int initClient(SOCKET* pSocket, char* pIPAddress, int iPort) {
	int outcome = 1;
	int iRet;
	//
	if (pSocket == NULL || pIPAddress == NULL) {
		outcome = 2;
	}
	else {
		struct hostent *hp = gethostbyname(pIPAddress);
		if (hp == NULL) {
			// Use pIPAddress
		}
		else {
			int index = 0;																				// Get 1st IP Address only
			if (hp->h_addr_list[index] != NULL) {
				pIPAddress = inet_ntoa(*(struct in_addr*)(hp->h_addr_list[index]));
			}
		}
		//
		pSocket->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (pSocket->sock <= 0) {
			outcome = 3;
		}
		else {
			if (iPort < 0 || iPort > 65535) {
				outcome = 4;
			}
			else {
				memset(&(pSocket->otherAddr), 0, sizeof(struct sockaddr_in));     	/* Zero out address structure */
				pSocket->otherAddr.sin_family      = AF_INET;             				/* Internet address family */
				pSocket->otherAddr.sin_addr.s_addr = inet_addr(pIPAddress);   			/* Server IP address */
				pSocket->otherAddr.sin_port        = htons(iPort); 						/* Server port */
				//
				iRet = connect(pSocket->sock, (struct sockaddr *)(&(pSocket->otherAddr)), sizeof(struct sockaddr_in));
				if (iRet != 0) {
					outcome = 5;
				}
				else {
					outcome = SUCCESS;
				}
			}
		}
	}
	//
	return outcome;
}



int initServer(SOCKET* pSocket, int iPort) {
	int outcome = 1;
	int iRet;
	//
	if (pSocket == NULL) {
		outcome = 2;
	}
	else {
		pSocket->sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (pSocket->sock <= 0) {
			outcome = 3;
		}
		else {
			if (iPort < 0 || iPort > 65535) {
				outcome = 4;
			}
			else {
				memset(&(pSocket->selfAddr), 0, sizeof(struct sockaddr_in));     	/* Zero out structure */
				pSocket->selfAddr.sin_family      = AF_INET;             			/* Internet address family */
				pSocket->selfAddr.sin_addr.s_addr = htonl(INADDR_ANY);   			/* Server IP address */
				pSocket->selfAddr.sin_port        = htons(iPort); 						/* Server port */
				//
				iRet = bind(pSocket->sock, (struct sockaddr *)(&(pSocket->selfAddr)), sizeof(struct sockaddr_in));
				if (iRet != 0) {
					outcome = 5;
				}
				else {
					iRet = listen(pSocket->sock, MAXPENDING);
					if (iRet != 0) {
						outcome = 6;
					}
					else {
						outcome = SUCCESS;
					}
				}
			}
		}
	}
	//
	return outcome;
}


int socketSend(SOCKET* pSocket, char* pData, int len) {
	int ret = 1;
	//
	while (TRUE) {
		int lenSent = send(pSocket->sock, pData, len, 0);
		//
		if (lenSent > 0) {																						// Send success
			len = len - lenSent;																					// Remaining length
			pData = pData + lenSent;																			// Remaining data
			//
			if (len == 0) {																						// Send complete
				ret = SUCCESS;
				break;
			}
			else if (len < 0) {																					// Never here
				ret = 2;
				break;
			}
			else {																									// Send not complete yet
				// More to send. Continue
			}
		}
		else {																										// Send failure
			ret = 3;
			break;
		}
	}
	//
	return ret;
}


int socketRecv(SOCKET* pSocket, char* pBuffer, int len) {
	int ret = 1;
	//
	while (TRUE) {
		int lenRecv = recv(pSocket->sock, pBuffer, len, 0);
		//
		if (lenRecv > 0) {																						// Receive success
			len = len - lenRecv;
			pBuffer = pBuffer + lenRecv;
			//
			if (len == 0) {																						// Receive complete
				ret = SUCCESS;
				break;
			}
			else if (len<0) {
				ret = 2;
				break;
			}
			else {																									// Receive not complete yet
				// More to receive. Continue
			}
		}
		else {
			ret = 3;																									// Receive failure
			break;
		}
	}
	//
	return ret;
}
