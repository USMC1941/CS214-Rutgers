#ifndef SORTER_H
#define SORTER_H


// Structure passed inside the thread function
typedef struct SortingParam {
	char inFullFileName[3 * PATH_MAX + NAME_MAX + 1];	// Full file name including path
	char sortingKeys[MAX_KEY_LENGTH];						// Sorting keys
	int 	isFile;													// Is file or directory
} SortingParam;


/**
 * Perform sorting with sortingKey
 * @param inParentPath    Parent path of inPath
 * @param inPath          Input path name
 * @param inName          Input file name
 * @param sortingKeyInput Key for sorting
 * @param pSortingParam   SortingParam structure
 */
void setSortingParam(const char* inParentPath, const char* inPath, const char* inName, const char* sortingKeyInput, SortingParam* pSortingParam);


/**
 * Thread function to handle one file or one directory. It checks that runningThreadCount will decrease when a thread exits.
 * @param  input     				Pointer to SortingParam
 * @param  return  					Nothing
 */
void* threadFunc(void* input);


/**
 * Perform actual work of sending a file to server for sorting using socket from socket pool.
 * @param pSortingParam Pointer to SortingParam which includes information about file
 * @param pSocket       Pointer to Socket
 */
void* sendingOneFile(SortingParam* pSortingParam, SOCKET* pSocket);


/**
 * Handling one file. It calls sendingOneFile to do actual work. Make sure the releaseSocket is called as sendingOneFile has a few return calls
 * @param pInput Pointer to input
 */
void* handleOneFile(void* pInput);


/**
 * Function to handle one file or one directory.
 * @param  input     				Pointer to SortingParam
 * @param  return  					Success or failure
 */
int handleFileOrDir(void* input);


/**
 * Get session ID from server using socket from socket pool
 * @param  pSocket Pointer to Socket
 * @return         Success or failure.
 */
int getSessionID(SOCKET* pSocket);


/**
 * Request sorted result from server for a session ID using socket from socket pool
 * @param pSocket     Pointer to Socket
 * @param pOutDir     Output directory
 * @param pSortingKey Sorting key as part of file name
 */
void outputResult(SOCKET* pSocket, char* pOutDir, char* pSortingKey);


/**
 * Print error messages.
 */
void outputUsage();



#endif