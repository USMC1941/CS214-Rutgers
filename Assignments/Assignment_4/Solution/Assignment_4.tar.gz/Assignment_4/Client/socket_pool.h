#ifndef SOCKET_POOL_H
#define SOCKET_POOL_H


typedef struct SocketPool {
	int 					poolSize;												// Size of the socket pool
	SOCKET* 				arraySocket;											// Array of struct SOCKET
	pthread_t* 			arrayTID;												// Array of pthread_t: the threads that are using the sockets at
	//
	pthread_mutex_t 	pool_mutex;												// mutex to protect SOCKET and pthread_t arrays
	sem_t					pool_sem;												// Semaphore for the pool
} SocketPool;


/**
 * Initialize a client SocketPool structure
 * @param  pSocketPool Pointer to SocketPool structure
 * @param  size        Number of sockets in the SocketPool
 * @param  pIPAddress  IP Address of the server
 * @param  iPort       Port of the server
 * @return             Success or failure
 */
int initializeSocketPool(SocketPool* pSocketPool, int size, char* pIPAddress, int iPort);


/**
 * Close all sockets in the socket pool and frees allocated memory and destroy mutex and semaphore
 * @param pSocketPool Pointer to Socket Pool structure
 */
void cleanSocketPool(SocketPool* pSocketPool);


/**
 * Get one socket from socket pool. Thread ID is used to identify which thread is using the socket for get and release.
 * @param  pSocketPool Pointer to Socket Pool structure
 * @return             Pointer to Socket
 */
SOCKET* getSocket(SocketPool* pSocketPool);


/**
 * Release socket back into the socket pool after finishing
 * @param pSocketPool Pointer to Socket Pool structure
 */
void releaseSocket(SocketPool* pSocketPool);



#endif