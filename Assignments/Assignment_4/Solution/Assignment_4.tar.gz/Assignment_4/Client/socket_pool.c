#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>

#include "../Shared/global.h"
#include "../Shared/socket.h"
#include "socket_pool.h"


/**
 * Initialize a client SocketPool structure
 * @param  pSocketPool Pointer to SocketPool structure
 * @param  size        Number of sockets in the SocketPool
 * @param  pIPAddress  IP Address of the server
 * @param  iPort       Port of the server
 * @return             Success or failure
 */
int initializeSocketPool(SocketPool* pSocketPool, int size, char* pIPAddress, int iPort) {
	int outcome = SUCCESS;																											// Default success
	//
	if (pSocketPool == NULL || size == 0 || pIPAddress == NULL || (iPort < 0 || iPort > 65535)) {
		outcome = 1;
	}
	else {
		pSocketPool->poolSize 		= 0;
		pSocketPool->arraySocket 	= NULL;
		pSocketPool->arrayTID 		= NULL;
		//
		pSocketPool->arraySocket = (SOCKET*)malloc(sizeof(SOCKET) * size);											// Allocate memory for array of sockets
		pSocketPool->arrayTID = (pthread_t*)malloc(sizeof(pthread_t) * size);										// Allocate memory for array of TIDs
		//
		if (pSocketPool->arraySocket == NULL || pSocketPool->arrayTID == NULL) {
			outcome = 2;
		}
		else {
			int index;
			for (index = 0; index < size; index++) {
				int iRet = initClient(pSocketPool->arraySocket + index, pIPAddress, iPort);					// Create sockets connecting to server
				if (iRet != SUCCESS) {
					outcome = 3;
					break;
				}
				else {
					*(pSocketPool->arrayTID + index) = 0;																	// Mark them available
				}
			}
		}
	}
	//
	if (outcome == SUCCESS) {
		pSocketPool->poolSize = size;
		//
		pthread_mutex_init(&(pSocketPool->pool_mutex), NULL);															//pSocketPool->pool_mutex 	= PTHREAD_MUTEX_INITIALIZER;
		sem_init(&(pSocketPool->pool_sem), 0, size);																		// Same process
	}
	else if (pSocketPool) {
		pSocketPool->poolSize = 0;
	}
	//
	return outcome;
}


/**
 * Close all sockets in the socket pool and frees allocated memory and destroy mutex and semaphore
 * @param pSocketPool Pointer to Socket Pool structure
 */
void cleanSocketPool(SocketPool* pSocketPool) {
	if (pSocketPool != NULL) {
		if (pSocketPool->arraySocket) {
			int index;
			for (index = 0; index < pSocketPool->poolSize; index++) {
				close((pSocketPool->arraySocket + index)->sock);
			}
		}
		//
		if (pSocketPool->arraySocket) {
			free(pSocketPool->arraySocket);
		}
		if (pSocketPool->arrayTID) {
			free(pSocketPool->arrayTID);
		}
		//
		pthread_mutex_destroy(&pSocketPool->pool_mutex);
		sem_destroy(&(pSocketPool->pool_sem));
	}
}


/**
 * Get one socket from socket pool. Thread ID is used to identify which thread is using the socket for get and release.
 * @param  pSocketPool Pointer to Socket Pool structure
 * @return             Pointer to Socket
 */
SOCKET* getSocket(SocketPool* pSocketPool) {
	sem_wait(&(pSocketPool->pool_sem));																				// Wait for semaphore.
	//
	SOCKET* pOut = NULL;
	//
	pthread_mutex_lock(&(pSocketPool->pool_mutex));																// Obtain mutex first before modifying shared data structure
	{
		int index;
		for (index = 0; index < pSocketPool->poolSize; index++) {
			if (*(pSocketPool->arrayTID + index) == 0) {															// 0 means not used by any thread
				pOut = pSocketPool->arraySocket + index;
				*(pSocketPool->arrayTID + index) = pthread_self();												// Mark it as used
				break;
			}
		}
	}
	pthread_mutex_unlock(&(pSocketPool->pool_mutex));															// Release mutex lock.
	//
	return pOut;
}


/**
 * Release socket back into the socket pool after finishing
 * @param pSocketPool Pointer to Socket Pool structure
 */
void releaseSocket(SocketPool* pSocketPool) {
	pthread_mutex_lock(&(pSocketPool->pool_mutex));																// Obtain mutex first before modifying shared data structure
	{
		pthread_t tid = pthread_self();
		int index;
		for (index = 0; index < pSocketPool->poolSize; index++) {
			if (*(pSocketPool->arrayTID + index) == tid) {														// Socket identified by TID is one to release
				*(pSocketPool->arrayTID + index) = 0;																// Set it as not used so other threads can use it
				break;
			}
		}
	}
	pthread_mutex_unlock(&(pSocketPool->pool_mutex));															// Release mutex lock.
	//
	sem_post(&(pSocketPool->pool_sem));																				// Exit semaphore
}
