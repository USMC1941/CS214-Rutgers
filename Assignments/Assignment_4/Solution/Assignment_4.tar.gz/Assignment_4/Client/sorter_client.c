#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>

#include "../Shared/global.h"
#include "../Shared/helper.h"
#include "../Shared/socket.h"
#include "../Shared/protocol.h"
#include "sorter_client.h"
#include "socket_pool.h"



// Session ID , does not need to protect as read only access by multiple thread.
int gSessionID;



// These 2 global variables will be accessed by all threads. They need to be protected
volatile int 		runningThreadCount 	= 0;						// Number of threads running
volatile int 		totalThreadCount 	= 0;							// Total Number of threads running



// Socket pool
SocketPool 			socketPool;



// For multiple thread
pthread_mutex_t 	data_mutex 	= PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t 	data_cond 	= PTHREAD_COND_INITIALIZER;
pthread_attr_t 	attr;




// Main thread will obtain session ID and get sorted result from server and output file
// For each file and subdirectory, a thread is created. That thread will send the file to the server to sort.
int main(int argc, char* argv[]) {
	// Check for right number of inputs
	if (argc == 7 || argc == 9 || argc == 11 || argc == 13) {																			// args = 2 * number_of_params + 1
		// Good
	}
	else {
		fprintf(stderr, "Invalid number of parameters: %d!\n", argc);
		outputUsage();
		return 1;
	}

	// Parameters
	char* pSortingKey 		= NULL;		// -c Required
	char* pInDir				= NULL;		// -d Optional
	char* pOutDir				= NULL;		// -o Optional
	char* pSHost 				= NULL;		// -h Required
	char* pSPort				= NULL;		// -p Required
	char* pSktPoolSize 		= NULL;		// -s Optional
	//
	int   iSPort				= -1;
	int   iSktPoolSize		= -1;

	// Find parameters
	int i;
	for (i = 1; i < argc; i = i + 2) {
		char* pOption = argv[i];
		//
		if (strcmp(pOption, "-c") == 0) {
			if (pSortingKey == NULL) {
				pSortingKey = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else if (strcmp(pOption, "-d") == 0) {
			if (pInDir == NULL) {
				pInDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else if (strcmp(pOption, "-o") == 0) {
			if (pOutDir == NULL) {
				pOutDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else if (strcmp(pOption, "-h") == 0) {
			if (pSHost == NULL) {
				pSHost = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else if (strcmp(pOption, "-p") == 0) {
			if (pSPort == NULL) {
				pSPort = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else if (strcmp(pOption, "-s") == 0) {
			if (pSktPoolSize == NULL) {
				pSktPoolSize = argv[i + 1];
			}
			else {
				fprintf(stderr, "Parameter error: %s!\n", pOption);
				outputUsage();
				return 1;
			}
		}
		else {
			fprintf(stderr, "Invalid parameter options %s!\n", pOption);
			outputUsage();
			return 1;
		}
	}

	// Verification of mandatory parameters
	if (pSortingKey == NULL) {
		fprintf(stderr, "Required Parameters: column_name not inputed!\n");
		outputUsage();
		return 1;
	}
	else if (pSHost == NULL) {
		fprintf(stderr, "Required Parameters: host_name not inputed!\n");
		outputUsage();
		return 1;
	}
	else if (pSPort == NULL) {
		fprintf(stderr, "Required Parameters: server port not inputed!\n");
		outputUsage();
		return 1;
	}

	// Convert server port to int & verify
	iSPort = atoi(pSPort);
	if (iSPort < 0 || iSPort > 65535) {
		fprintf(stderr, "Required Parameters: server port is not within range!\n");
		outputUsage();
		return 1;
	}

	// Check and set iSktPoolSize. If not in parameter, set to default values.
	if (pSktPoolSize == NULL) {
		iSktPoolSize = SOCKET_POOL_DEFAULT;
	}
	else {
		iSktPoolSize = atoi(pSktPoolSize);
		if (iSktPoolSize < SOCKET_POOL_MIN) {
			iSktPoolSize = SOCKET_POOL_MIN;
		}
		else if (iSktPoolSize > SOCKET_POOL_MAX) {
			iSktPoolSize = SOCKET_POOL_MAX;
		}
	}

	// Default input directory.
	if (pInDir == NULL) {
		pInDir = ".";
	}

	// Create output directory if not exits
	if (pOutDir != NULL && strcmp(pOutDir, ".") != 0) {
		mkdir(pOutDir, 0700);
	}

	int iRet;

	// Initialize Socket Pool
	iRet = initializeSocketPool(&socketPool, iSktPoolSize, pSHost, iSPort);
	if (iRet != 0) {
		fprintf(stderr, "Socket Error: %s\n", strerror(errno));
		fprintf(stderr, "Socket Pool initialization failed with outcome = %d\n", iRet);
		outputUsage();
		return 1;
	}

	// Get session ID from server. Get Socket from Pool to communicate with server. Release it after use.
	SOCKET* pSocket = getSocket(&socketPool);
	iRet = getSessionID(pSocket);
	releaseSocket(&socketPool);
	if (iRet!=0) {
		fprintf(stderr, "Could not get Session ID from server with outcome = %d\n", iRet);
		outputUsage();
		return 1;
	}

	//init pthread_attr: thread attr is detached. So no need to wait for the threads to exit
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	// Prepare Parameter
	SortingParam* pSortingParam = (SortingParam*)malloc(sizeof(SortingParam));						// Will be free inside function handleFileOrDir
	setSortingParam(NULL, pInDir, NULL, pSortingKey, pSortingParam);

	// Handling parent directory
	handleFileOrDir(pSortingParam);

	// Main thread finish handling input directory by creating threads to handle subdirectories and files
	pthread_mutex_lock(&data_mutex);										// Get lock first
	while (runningThreadCount > 0) {										// wait for all threads to exit
		pthread_cond_wait(&data_cond, &data_mutex);
	}
	pthread_mutex_unlock(&data_mutex);									// Free lock
	//
	pSocket = getSocket(&socketPool);
	outputResult(pSocket, pOutDir, pSortingKey);						// Get sorting result and output to file
	releaseSocket(&socketPool);

	cleanSocketPool(&socketPool);											// Close all sucket
	//
	return 0;
}



/**
 * Get session ID from server using socket from socket pool
 * @param  pSocket Pointer to Socket
 * @return         Success or failure.
 */
int getSessionID(SOCKET* pSocket) {
	int outcome = 0;
	//
	Message messageSend;
	Message messageRecv;
	//
	messageSend.msgType = MESSAGE_TYPE_REQ_SESS_ID;
	if (socketSend(pSocket, (char*)&messageSend, sizeof(Message)) != 0) {
		outcome = 1;
	}
	else {
		if (socketRecv(pSocket, (char*)&messageRecv, sizeof(Message)) != 0) {
			outcome = 2;
		}
		else {
			gSessionID = messageRecv.protocol.respSessionID.sessionID;
		}
	}
	//
	return outcome;
}



/**
 * Request sorted result from server for a session ID using socket from socket pool
 * @param pSocket     Pointer to Socket
 * @param pOutDir     Output directory
 * @param pSortingKey Sorting key as part of file name
 */
void outputResult(SOCKET* pSocket, char* pOutDir, char* pSortingKey) {
	Message messageSend;
	Message messageRecv;
	//
	messageSend.msgType = MESSAGE_TYPE_REQ_GET_RESULT;
	messageSend.protocol.reqGetSorted.sessionID = gSessionID;
	if (socketSend(pSocket, (char*)&messageSend, sizeof(Message)) != 0) {
		fprintf(stderr, "Error in sending to get result\n");
	}
	//
	if (socketRecv(pSocket, (char*)&messageRecv, sizeof(Message)) != 0) {
		fprintf(stderr, "Error in receiving for getting result\n");
	}

	if (messageRecv.protocol.respGetSorted.status != STATUS_GET_RESULT_OK) {
		if (messageRecv.protocol.respGetSorted.status == STATUS_GET_RESULT_NO) {
			fprintf(stderr, "Data Not Available for this session. Status = %d\n", messageRecv.protocol.respGetSorted.status);
		}
		else if (messageRecv.protocol.respGetSorted.status == STATUS_GET_RESULT_EMPTY) {
			fprintf(stderr, "No sorted Data. Status = %d\n", messageRecv.protocol.respGetSorted.status);
		}
		else {
			fprintf(stderr, "Sorted Data Not Available. Status = %d\n", messageRecv.protocol.respGetSorted.status);
		}
	}

	int len = messageRecv.protocol.respGetSorted.dataLength;
	if (len>0) {
		// Create output file name
		char outFullFileName[3 * PATH_MAX + NAME_MAX + 1];
		strcpy(outFullFileName, "");
		if (pOutDir != NULL) {
			strcat(outFullFileName, pOutDir);
			strcat(outFullFileName, "/");
		}
		strcat(outFullFileName, "AllFiles-sorted-");
		strcat(outFullFileName, pSortingKey);
		strcat(outFullFileName, ".csv");
		//
		FILE *file = fopen(outFullFileName, "w");
		if (file == NULL) {
			fprintf(stderr, "Error Openning File: %s\n", strerror(errno));
		}
		//
		char buf[BUFFER_SIZE];
		unsigned int lenRemain = len;
		while (lenRemain>0) {
			if (lenRemain>BUFFER_SIZE) {
				socketRecv(pSocket, buf, BUFFER_SIZE);
				if (file != NULL) {
					fwrite(buf, sizeof(char), BUFFER_SIZE, file);
				}
				lenRemain -= BUFFER_SIZE;
			}
			else {
				socketRecv(pSocket, buf, lenRemain);
				if (file != NULL) {
					fwrite(buf, sizeof(char), lenRemain, file);
				}
				lenRemain = 0;
			}
		}
		//
		if (file != NULL) {
			fclose(file);
		}
	}
}



/**
 * Handling one file. It calls sendingOneFile to do actual work. Make sure the releaseSocket is called as sendingOneFile has a few return calls
 * @param pInput Pointer to input
 */
void* handleOneFile(void* pInput) {
	SortingParam* pSortingParam = (SortingParam*)pInput;
	//
	SOCKET* pSocket = getSocket(&socketPool);
	sendingOneFile(pSortingParam, pSocket);
	releaseSocket(&socketPool);
	//
	return NULL;
}



/**
 * Perform actual work of sending a file to server for sorting using socket from socket pool.
 * @param pSortingParam Pointer to SortingParam which includes information about file
 * @param pSocket       Pointer to Socket
 */
void* sendingOneFile(SortingParam* pSortingParam, SOCKET* pSocket) {
	struct stat file_stats;
	unsigned int fileSize;
	if (stat(pSortingParam->inFullFileName, &file_stats)<0) {
		fprintf(stderr, "Error in getting file %s size with error %s\n", pSortingParam->inFullFileName, strerror(errno));
		return NULL;
	}
	else {
		fileSize = file_stats.st_size;
		if (fileSize == 0) {
			fprintf(stderr, "Empty file %s\n", pSortingParam->inFullFileName);
			return NULL;
		}
	}

	Message messageSend;
	messageSend.msgType = MESSAGE_TYPE_REQ_SORTING;
	messageSend.protocol.reqDoSorting.sessionID = gSessionID;
	messageSend.protocol.reqDoSorting.sortingKeyLength = strlen(pSortingParam->sortingKeys);
	messageSend.protocol.reqDoSorting.dataLength = fileSize;

	if (socketSend(pSocket, (char*)&messageSend, sizeof(Message)) != SUCCESS) {
		fprintf(stderr, "Error in sending message for sorting.\n");
		return NULL;
	}
	//
	//Send sorting key
	if (socketSend(pSocket, pSortingParam->sortingKeys, messageSend.protocol.reqDoSorting.sortingKeyLength) != SUCCESS) {
		fprintf(stderr, "Error in sending Sorting Key.\n");
		return NULL;
	}
	//
	//Send the file to server
	char buf[BUFFER_SIZE];
	FILE *file = fopen(pSortingParam->inFullFileName, "r");
	if (file == NULL) {
		fprintf(stderr, "Error in opening file: %s\n", strerror(errno));
		return NULL;
	}
	else {
		unsigned int lenRemain = fileSize;											// Send the while file 8k at a time
		while (lenRemain > 0) {
			size_t byteread = 0;
			if (lenRemain>BUFFER_SIZE) {
				byteread = fread(buf, sizeof(char), BUFFER_SIZE, file); 			// reads an array of doubles
			}
			else {
				byteread = fread(buf, sizeof(char), lenRemain, file); 				// reads an array of doubles
			}
			//
			if (byteread>0) {
				socketSend(pSocket, buf, byteread);
				lenRemain -= byteread;
			}
		}
	}
	if (file != NULL) {
		fclose(file);
	}
	//
	//
	Message messageRecv;
	socketRecv(pSocket, (char*)&messageRecv, sizeof(Message));
	if (messageRecv.protocol.respDoSorting.outcome != OUTCOME_SORTING_OK) {
		if (messageRecv.protocol.respDoSorting.outcome == OUTCOME_SORTING_NO_SESSION) {
			printf("Server could not sort file as there is no session: %s %d\n", pSortingParam->inFullFileName, messageRecv.protocol.respDoSorting.outcome);
		}
		else if (messageRecv.protocol.respDoSorting.outcome == OUTCOME_SORTING_FAILED) {
			printf("Server could not sort file due to wrong format: %s %d\n", pSortingParam->inFullFileName, messageRecv.protocol.respDoSorting.outcome);
		}
		else {
			printf("Server could not sort file: %s %d\n", pSortingParam->inFullFileName, messageRecv.protocol.respDoSorting.outcome);
		}
	}

	return NULL;
}




/**
 * Thread function to handle one file or one directory. It checks that runningThreadCount will decrease when a thread exits.
 * @param  input     				Pointer to SortingParam
 * @param  return  					Nothing
 */
void* threadFunc(void* input) {
	handleFileOrDir(input);				// Handle a file or directory
	//
	// Thread is about to exit. put output to global linked-list and signal main thread
	pthread_mutex_lock(&data_mutex);									// Get lock first
	//
	runningThreadCount--;												// Since this thread is exiting, reduce runningThreadCount by 1
	//
	pthread_cond_signal(&data_cond);									// Only main thread are waiting
	//
	pthread_mutex_unlock(&data_mutex);								// Release lock
	//
	return NULL;
}




/**
 * Function to handle one file or one directory.
 * @param  input     				Pointer to SortingParam
 * @param  return  					Success or failure
 */
int handleFileOrDir(void* input) {
	SortingParam* pSortingParam = (SortingParam*)input;
	//
	if (pSortingParam->isFile) {																														// Handle a file
		handleOneFile(pSortingParam);
	}
	else {																																						// Handle directory
		// Loop through all items in the folder
		DIR *dir = NULL;
		struct dirent *entry;
		//
		if (!(dir = opendir(pSortingParam->inFullFileName))) {																			// Coudl not open directory. Do nothing
			fprintf(stderr, "Could not open directory %s: %s\n", pSortingParam->inFullFileName, strerror(errno));
		}
		else {
			while ((entry = readdir(dir)) != NULL) {
				if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {											// Current or parent directory
					// Ignore
				}
				else if (entry->d_type == DT_DIR) {																								// Directory
					SortingParam* pSortingParamChild = (SortingParam*)malloc(sizeof(SortingParam));								// File or directory info for child thread
					setSortingParam(pSortingParam->inFullFileName, entry->d_name, NULL, pSortingParam->sortingKeys, pSortingParamChild);
					//
					pthread_mutex_lock(&data_mutex);
					runningThreadCount++;
					totalThreadCount++;
					pthread_mutex_unlock(&data_mutex);
					//
					pthread_t thread_id = 0;
					pthread_create(&thread_id, &attr, threadFunc, pSortingParamChild);
				}
				else {																																	// File: if (entry->d_type != DT_DIR)
					int lenName = strlen(entry->d_name);
					if (lenName > 4 && strcicmp(entry->d_name + lenName - 4, ".csv") == 0) {					// Check if file is .csv
						SortingParam* pSortingParamChild = (SortingParam*)malloc(sizeof(SortingParam));
						setSortingParam(pSortingParam->inFullFileName, NULL, entry->d_name, pSortingParam->sortingKeys, pSortingParamChild);
						//
						pthread_mutex_lock(&data_mutex);
						runningThreadCount++;
						totalThreadCount++;
						pthread_mutex_unlock(&data_mutex);
						//
						pthread_t thread_id = 0;
						pthread_create(&thread_id, &attr, threadFunc, pSortingParamChild);
					}
					else {
						// Not a csv file. Ignore
					}
				}
			}
		}
		//
		if (dir) {
			closedir(dir);
		}
	}
	//
	free(pSortingParam);																													// mallco be parent. free by child.
	//
	return 0;
}


/**
 * Perform sorting with sortingKey
 * @param inParentPath    Parent path of inPath
 * @param inPath          Input path name
 * @param inName          Input file name
 * @param sortingKeyInput Key for sorting
 * @param pSortingParam   SortingParam structure
 */
void setSortingParam(const char* inParentPath, const char* inPath, const char* inName, const char* sortingKeyInput, SortingParam* pSortingParam) {
	strcpy(pSortingParam->sortingKeys, sortingKeyInput);
	//
	strcpy(pSortingParam->inFullFileName, "");												// Current Directory
	//
	int emptyParentPath 	= inParentPath == NULL || strlen(inParentPath) == 0;
	int emptyPath 			= inPath == NULL || strlen(inPath) == 0;
	int emptyName 			= inName == NULL || strlen(inName) == 0;
	//
	if (emptyParentPath && emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, ".");
		pSortingParam->isFile = FALSE;
	}
	else if (emptyParentPath && emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (emptyParentPath && !emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inPath);
		pSortingParam->isFile = FALSE;
	}
	else if (emptyParentPath && !emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (!emptyParentPath && emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		pSortingParam->isFile = FALSE;
	}
	else if (!emptyParentPath && emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
	else if (!emptyParentPath && !emptyPath && emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inPath);
		pSortingParam->isFile = FALSE;
	}
	else if (!emptyParentPath && !emptyPath && !emptyName) {
		strcat(pSortingParam->inFullFileName, inParentPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inPath);
		strcat(pSortingParam->inFullFileName, "/");
		strcat(pSortingParam->inFullFileName, inName);
		pSortingParam->isFile = TRUE;
	}
}


/**
 * Print error messages.
 */
void outputUsage() {
	fprintf(stderr, "\n");
	fprintf(stderr, "Usage: ./sorter_client -c column_name -h host_name -p port_number -d input_dir -o output_dir -s num_of_sockets_in_pool\n");
	fprintf(stderr, "       Parameters -c -h -p are mandatory\n");
	fprintf(stderr, "       Parameters -d -o -s are optional\n");
}