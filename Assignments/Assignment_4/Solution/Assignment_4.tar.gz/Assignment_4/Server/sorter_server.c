#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <linux/limits.h>

#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "session_linkedlist.h"
#include "csvsorter.h"
#include "../Shared/protocol.h"
#include "../Shared/global.h"
#include "../Shared/socket.h"
#include "sorter_server.h"
#include "recordarray_linkedlist.h"
#include "mergesort.h"
#include "tokenizer.h"


// These 2 variables need to be protected with mutexes
SESSION_LINKED_LIST 	sessionList 										= NULL;
unsigned int 			gSessionID 											= 0;


// Function to compare 2 records
PFUNC_COMPARE_DATA 	g_pFuncCompare 									= compare;


// Mutex and thread attribute
pthread_mutex_t 		data_mutex 											= PTHREAD_MUTEX_INITIALIZER;
pthread_attr_t 		attr;



int main(int argc, char *argv[]) {
	if (argc != 2) {																				// Check for correct inputs
		fprintf(stderr, "Usage: ./sorter_server <Server Port>\n");
		return 1;
	}

	// Convert port to int and check if within range
	int iSPort = atoi(argv[1]);
	if (iSPort < 0 || iSPort > 65535) {
		fprintf(stderr, "Required Parameters: server port is not within range!\n");
		return 1;
	}

	// Initialize server socket
	SOCKET sktServer;
	int iRet = initServer(&sktServer, iSPort);
	if (iRet != 0) {
		fprintf(stderr, "Server socket initialization failed. Outcome = %d. Error= %s\n", iRet, strerror(errno));
		return 1;
	}

	// Ignore Broken pipe signal from OS
	signal(SIGPIPE, SIG_IGN);

	//init pthread_attr: thread attr is detached. So no need to wait for the threads
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

	// Main loop. Recieves connection and spawns threads to handle it
	printf("Received connections from: ");
	fflush(stdout);
	for (;;) {
		// Allocate a SOCKET structure that pass inside a thread
		SOCKET* pSocket = (SOCKET*)malloc(sizeof(SOCKET));
		//
		// Waiting for connections
		unsigned int clntLen = sizeof(struct sockaddr_in);
		pSocket->sock = accept(sktServer.sock, (struct sockaddr *)(&(pSocket->otherAddr)), &clntLen);

		if (pSocket->sock <= 0) {																			// Error
			fprintf(stderr, "Error in accept call.\n");
			free(pSocket);
		}
		else {																									// Handle connections
			//printf("IP address is: %s\n", inet_ntoa(client_addr.sin_addr));
			//printf("port is: %d\n", (int) ntohs(client_addr.sin_port));
			//
			printf("%s,", inet_ntoa(pSocket->otherAddr.sin_addr));								// inet_ntoa is not thread-safe. OK as only main thread comes here.
			fflush(stdout);
			//
			pthread_t  tid;
			pthread_create(&tid, &attr, HandleTCPClient, (void*)(pSocket));
		}
	 }

	 /* NOT REACHED */
	 return 0;
}



/**
 * Thread function to handle Socket connections
 * @param pInput Pointer to input Socket
 */
void* HandleTCPClient(void* pInput) {
	SOCKET* pSocket = (SOCKET*)pInput;

	Message messageRecv;
	Message messageResp;

	while (TRUE) {																									// Get into request/response loop
		memset((void*)(&messageRecv), 0, sizeof(Message));												// Reset messageRecv (to be sure)
		memset((void*)(&messageResp), 0, sizeof(Message));												// Reset messageResp (to be sure)
		//
		int iRet;
		if ((iRet = socketRecv(pSocket, (char*)(&messageRecv), sizeof(Message))) != 0) {		// Receive request from client
			//fprintf(stderr, "Socket Receiving error: %s\n", strerror(errno));
			break;
		}
		else {
			if (messageRecv.msgType == MESSAGE_TYPE_REQ_SESS_ID) {									// Request for session ID
				PSession pSession = (Session*)malloc(sizeof(Session));
				//
				//
				pthread_mutex_lock(&data_mutex);
				{	initializeSession(pSession, gSessionID);												// Need to be inside lock since gSessionID is accessed by multiple threads
					//
					messageResp.msgType = MESSAGE_TYPE_RESP_SESS_ID;
					messageResp.protocol.respSessionID.sessionID = gSessionID;						// gSessionID needs to be protected
					//
					gSessionID++;
					insertSession(&sessionList, pSession);													// sessionList is accessed by multiple threads
				}
				pthread_mutex_unlock(&data_mutex);
				//
				//
				socketSend(pSocket, (char*)&messageResp, sizeof(Message));
			}
			else if (messageRecv.msgType == MESSAGE_TYPE_REQ_SORTING) {								// Request to perform sorting
				char* key = (char*)malloc(sizeof(char) * (messageRecv.protocol.reqDoSorting.sortingKeyLength + 1));
				if (socketRecv(pSocket, key, messageRecv.protocol.reqDoSorting.sortingKeyLength) != 0) {
					printf("Error receiving key\n");
				}
				else {
					*(key + messageRecv.protocol.reqDoSorting.sortingKeyLength) = '\0';
				}
				//
				char* data = (char*)malloc(sizeof(char) * (messageRecv.protocol.reqDoSorting.dataLength + 1));
				if (socketRecv(pSocket, data, messageRecv.protocol.reqDoSorting.dataLength) != 0) {
					printf("Error receiving data\n");
				}
				else {
					*(data + messageRecv.protocol.reqDoSorting.dataLength) = '\0';
				}

				RecordArray* pTemp = doSorting(data, key, messageRecv.protocol.reqDoSorting.dataLength);

				int sessionFound = 0;
				if (pTemp) {
					pthread_mutex_lock(&data_mutex);
					{	PSession pSession = searchReturnSession(&sessionList, messageRecv.protocol.reqDoSorting.sessionID);
						if (pSession) {
							sessionFound = 1;
							//
							if (pSession->pHeader == NULL) {																									// The header of teh first file reaches server will be the header of output
								pSession->pHeader = pTemp->pRaw;
							}
							insertOne(&(pSession->pRecordArray), pTemp);																					// Data
							// Sort and merge with previous results
							mergeTwo(pTemp, &(pSession->recordArraysTempOut[pSession->iCurrentOut]), &(pSession->recordArraysTempOut[(pSession->iCurrentOut + 1) % 2]));
							pSession->iCurrentOut = (pSession->iCurrentOut + 1) % 2;
						}
					}
					pthread_mutex_unlock(&data_mutex);
				}

				messageResp.msgType = MESSAGE_TYPE_RESP_SORTING;
				if (pTemp) {
					if (sessionFound) {
						messageResp.protocol.respDoSorting.outcome = OUTCOME_SORTING_OK;
					}
					else {
						messageResp.protocol.respDoSorting.outcome = OUTCOME_SORTING_NO_SESSION;
					}
				}
				else {
					messageResp.protocol.respDoSorting.outcome = OUTCOME_SORTING_FAILED;
				}
				socketSend(pSocket, (char*)&messageResp, sizeof(Message));

			}
			else if (messageRecv.msgType == MESSAGE_TYPE_REQ_GET_RESULT) {								// Request to get sorted result
				PSession pSession = NULL;
				pthread_mutex_lock(&data_mutex);
				{
					pSession = searchRemoveSession(&sessionList, messageRecv.protocol.reqDoSorting.sessionID);
				}
				pthread_mutex_unlock(&data_mutex);

				if (pSession) {
					RecordArray* pTemp = &(pSession->recordArraysTempOut[pSession->iCurrentOut]);
					//
					if (pTemp->dataLength > 0) {
						int headerLength = strlen(pSession->pHeader) + 1;												// 1 for '\n' to be added in a bit
						//
						messageResp.msgType = MESSAGE_TYPE_RESP_GET_RESULT;
						messageResp.protocol.respGetSorted.status = STATUS_GET_RESULT_OK;
						messageResp.protocol.respGetSorted.dataLength = headerLength + pTemp->dataLength;
						socketSend(pSocket, (char*)&messageResp, sizeof(Message));
						//
						*(pSession->pHeader + headerLength - 1) = '\n';													// Set to '\0'. Here set it back to '\n'
						socketSend(pSocket, (char*)pSession->pHeader, headerLength);
						//
						int sum = 0;
						int i;
						for (i = 0; i < pTemp->iSize; i++) {
							*((*(pTemp->recPtrArray + i))->pSKeyTerm) = (*(pTemp->recPtrArray + i))->chHold;			// Put back the char set to '\0' for sorting key
							//
							char* pRecord = (*(pTemp->recPtrArray + i))->recordData;
							int   recLen = strlen(pRecord);
							//
							*(pRecord + recLen) = '\n';																	// Put '\n' back
							socketSend(pSocket, pRecord, recLen + 1);
							sum += recLen + 1;
						}
						//
						if (pTemp->dataLength!=sum) {
							printf("Calculated length not equal to Actual Length %d %d\n", pTemp->dataLength, sum);
						}
					}
					else {
						messageResp.msgType = MESSAGE_TYPE_RESP_GET_RESULT;
						messageResp.protocol.respGetSorted.status = STATUS_GET_RESULT_EMPTY;
						messageResp.protocol.respGetSorted.dataLength = 0;
						socketSend(pSocket, (char*)&messageResp, sizeof(Message));
					}
					//
					cleanUpSession(pSession);
				}
				else {
					messageResp.msgType = MESSAGE_TYPE_RESP_GET_RESULT;
					messageResp.protocol.respGetSorted.status = STATUS_GET_RESULT_NO;
					messageResp.protocol.respGetSorted.dataLength = 0;
					socketSend(pSocket, (char*)&messageResp, sizeof(Message));
				}
			}
			else {																											// Invalid request
				fprintf(stderr, "Invalid message type received! %d\n", messageRecv.msgType);
				break;
			}
		}
	}

	close(pSocket->sock);    																							// Close client socket if socket is broken

	free(pSocket);																											// Free memory allocated from parent

	return NULL;
}


/**
 * Merge two sorted RecordArrays into one sorted
 * @param  p1     		First record array
 * @param  p2 			Second record arrasy
 * @param  pMerged    Merged recordarray
 */
void mergeTwo(PRecordArray p1, PRecordArray p2, PRecordArray pMerged) {
	resizePtrArray(pMerged, p1->iSize + p2->iSize);
	merge((void**)p1->recPtrArray, p1->iSize, (void**)p2->recPtrArray, p2->iSize, (void**)pMerged->recPtrArray, g_pFuncCompare);
	pMerged->iSize = p1->iSize + p2->iSize;
	p1->iSize = 0;
	p2->iSize = 0;
	//
	pMerged->dataLength		= p1->dataLength + p2->dataLength;
	//
	//p1->dataLength				= 0;
	//
	//p2->dataLength				= 0;
}