#ifndef RECORDARRAY_LINKED_LIST_H
#define RECORDARRAY_LINKED_LIST_H


/**
 * Cleans up linked list of FolderNode structure which corresponds to all the subdirectories of one parent directory.
 * @param ppFolderNode Input linked list
 */
void cleanUpRecordArrayList(PRecordArray* ppRecordArray);


/**
 * Insert a FolderNode structure into a linked list
 * @param ppFolderNode   Linked list of FolderNodes for subdirectories.
 * @param pOneFolderNode Input FolderNode structure to be added
 */
int insertOne(PRecordArray* ppRecordArray, PRecordArray ppOneRecordArray);


/**
 * While protected with mutex, take current output and set RecordArray list to empty
 * @param ppInRecordArray  Current output
 * @param ppOutRecordArray Variable to take in current output
 */
void swap(PRecordArray* ppInRecordArray, PRecordArray* ppOutRecordArray);


/**
 * Removes one RecordArray from head of linked list
 * @param  ppRecordArray Linked list of RecordArray
 * @return               RecordArray
 */
PRecordArray removeOne(PRecordArray* ppRecordArray);



#endif