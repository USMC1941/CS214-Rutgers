#ifndef CSVSORTER_H
#define CSVSORTER_H


/**
 * Perform sorting of a file as a buffer received from socket
 * @param  data   Contents of the file in buffer
 * @param  pKey   Sorting key
 * @param  length File length
 * @return        Pointer to sorted RecordArray
 */
RecordArray* doSorting(char* data, char* pKey, unsigned int length);

#endif
