#ifndef SESSION_LINKEDLIST_H
#define SESSION_LINKEDLIST_H


typedef struct Session {
	char* 					pHeader;						// 
	int 						data;							// SessionID. ID of the session
	PRecordArray 			pRecordArray;				// Linked list holding sorted .csv files
	RecordArray 			recordArraysTempOut[2];	// Two RecordArrays: one for output one for temparol storage to merge two files
	int 						iCurrentOut;				// The result of merged files. Will switch between 0 and 1 when mergeing files 
	//
	struct Session* 		next;							// For linked list
} Session;


typedef Session* PSession;


typedef Session* SESSION_LINKED_LIST;



/**
 * Insert Session into linked list of Sessions
 * @param  ppListHead Pointer to linked list
 * @param  pSession   Session to insert
 * @return            Success or failure
 */
int insertSession(SESSION_LINKED_LIST* ppListHead, PSession pSession);


/**
 * Search for a Session in the linked list identified by ID
 * @param  ppListHead Pointer to linked list
 * @param  id         ID
 * @return            Pointer to Session found
 */
PSession searchReturnSession(SESSION_LINKED_LIST* ppListHead, int id);


/**
 * Search for a Session in the linked list identified by ID. Remove it from linked list if found.
 * @param  ppListHead Pointer to linked list
 * @param  id         ID
 * @return            Pointer to Session found
 */
PSession searchRemoveSession(SESSION_LINKED_LIST* ppListHead, int id);


/**
 * Initialize Session structure with ID
 * @param pSession Pointer to Session
 * @param id       ID
 */
void initializeSession(PSession pSession, int id);


/**
 * Clean up Session structure and all its record arrays
 * @param pSession Pointer to Session
 */
void cleanUpSession(PSession pSession);


#endif