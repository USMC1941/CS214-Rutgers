#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "../Shared/global.h"
#include "sortingkey.h"
#include "record.h"
#include "mergesort.h"


/*
 Merges two sorted subarrays into one sorted array.
 First subarray is arr1 length n1
 Second subarray is arr2 length n2
 merged sorted array arr 
*/
void merge(void* arr1[], int n1, void* arr2[], int n2, void* arr[], PFUNC_COMPARE_DATA pFuncCompare) {
	int i = 0; 																// Initial index of first subarray
	int j = 0; 																// Initial index of second subarray
	int k = 0;																// Initial index of merged subarray
	while (i < n1 && j < n2) {
		if (pFuncCompare(arr1[i], arr2[j]) <= 0) {
			arr[k] = arr1[i];
			i++;
		}
		else {
			arr[k] = arr2[j];
			j++;
		}
		k++;
	}
	// Copy the remaining elements of arr1[], if there are any
	while (i < n1) {
		arr[k] = arr1[i];
		i++;
		k++;
	}

	// Copy the remaining elements of arr2[], if there are any
	while (j < n2) {
		arr[k] = arr2[j];
		j++;
		k++;
	}
}


/*
 Merges two subarrays of arr[].
 First subarray is arr[l..m]
 Second subarray is arr[m+1..r]
*/
void mergeSort(void* arr[], int l, int r, PFUNC_COMPARE_DATA pFuncCompare) {
	if (l < r) {
		// Same as (l+r)/2, but avoids overflow for large l and h
		int m = l + (r - l) / 2;
		//
		// Sort first and second halves
		mergeSort(arr, l, m, pFuncCompare);
		mergeSort(arr, m + 1, r, pFuncCompare);
		//
		int i, j;
		int n1 = m - l + 1;										// Size of 1st subarray
		int n2 = r - m;											// Size of 2nd subarray
		//
		// Create Temp Arrays to hold 1st and 2nd subarrays
		void* tempArr1[n1];
		void* tempArr2[n2];
		//
		// Copy data to temp arrays tempArr1[] and tempArr2[]
		for (i = 0; i < n1; i++) {
			tempArr1[i] = arr[l + i];
		}
		for (j = 0; j < n2; j++) {
			tempArr2[j] = arr[m + 1 + j];
		}
		//
		merge(tempArr1, n1, tempArr2, n2, arr + l, pFuncCompare);
	}
}
