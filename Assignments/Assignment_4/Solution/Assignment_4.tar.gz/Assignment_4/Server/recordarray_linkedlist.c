#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>

#include "../Shared/global.h"
#include "../Shared/helper.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "sorter_server.h"
#include "mergesort.h"
#include "csvsorter.h"
#include "recordarray_linkedlist.h"


/**
 * Cleans up linked list of FolderNode structure which corresponds to all the subdirectories of one parent directory.
 * @param ppFolderNode Input linked list
 */
void cleanUpRecordArrayList(PRecordArray* ppRecordArray) {
	if (ppRecordArray) {
		PRecordArray pListHead = *ppRecordArray;
		//
		if (pListHead) {
			PRecordArray pOneInList = pListHead;
			while (pOneInList) {
				PRecordArray pToBeFree = pOneInList;
				pOneInList = pOneInList->next;
				//
				cleanRecordArray(pToBeFree);
				free(pToBeFree);
			}
			pListHead = NULL;
		}
		//
		*ppRecordArray = NULL;
	}
}


/**
 * Insert a FolderNode structure into a linked list
 * @param ppFolderNode   Linked list of FolderNodes for subdirectories.
 * @param pOneFolderNode Input FolderNode structure to be added
 */
int insertOne(PRecordArray* ppRecordArray, PRecordArray ppOneRecordArray) {
	int outcome = FAILURE;
	//
	if (ppRecordArray) {
		if (ppOneRecordArray != NULL) {
			if (*ppRecordArray == NULL) {
				*ppRecordArray = ppOneRecordArray;
				ppOneRecordArray->next = NULL;
			}
			else {
				ppOneRecordArray->next = *ppRecordArray;
				*ppRecordArray = ppOneRecordArray;
			}
			//
			outcome = SUCCESS;
		}
	}
	//
	return outcome;
}


/**
 * While protected with mutex, take current output and set RecordArray list to empty
 * @param ppInRecordArray  Current output
 * @param ppOutRecordArray Variable to take in current output
 */
void swap(PRecordArray* ppInRecordArray, PRecordArray* ppOutRecordArray) {
	*ppOutRecordArray = *ppInRecordArray;
	*ppInRecordArray = NULL;
}


/**
 * Removes one RecordArray from head of linked list
 * @param  ppRecordArray Linked list of RecordArray
 * @return               RecordArray
 */
PRecordArray removeOne(PRecordArray* ppRecordArray) {
	PRecordArray pTemp = NULL;
	//
	if (ppRecordArray) {
		pTemp = *ppRecordArray;
		//
		// Remove from list
		if (pTemp) {
			*ppRecordArray = pTemp->next;
			pTemp->next = NULL;
		}
	}
	//
	return pTemp;
}
