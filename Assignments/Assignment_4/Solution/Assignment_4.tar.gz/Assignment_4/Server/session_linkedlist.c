#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#include "../Shared/global.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "recordarray_linkedlist.h"
#include "session_linkedlist.h"


/**
 * Insert Session into linked list of Sessions
 * @param  ppListHead Pointer to linked list
 * @param  pSession   Session to insert
 * @return            Success or failure
 */
int insertSession(SESSION_LINKED_LIST* ppListHead, PSession pSession) {
	int outcome = FAILURE;
	//
	if (ppListHead) {
		if (pSession) {
			if (*ppListHead == NULL) {									// Empty list: insert into head of the list
				*ppListHead = pSession;
				pSession->next = NULL;
			}
			else {
				pSession->next = *ppListHead;
				*ppListHead = pSession;
			}
			//
			outcome = SUCCESS;
		}
	}
	//
	return outcome;
}



/**
 * Search for a Session in the linked list identified by ID
 * @param  ppListHead Pointer to linked list
 * @param  id         ID
 * @return            Pointer to Session found
 */
PSession searchReturnSession(SESSION_LINKED_LIST* ppListHead, int id) {
	PSession cursor = (*ppListHead);
	while (cursor != NULL) {
		if (cursor->data != id) {
			cursor = cursor->next;
		}
		else {
			break;
		}
	}
	//
	return cursor;
}



/**
 * Search for a Session in the linked list identified by ID. Remove it from linked list if found.
 * @param  ppListHead Pointer to linked list
 * @param  id         ID
 * @return            Pointer to Session found
 */
PSession searchRemoveSession(SESSION_LINKED_LIST* ppListHead, int id) {
	if (ppListHead == NULL) {
		return NULL;
	}
	else if ((*ppListHead) == NULL) {
		return NULL;
	}
	//
	PSession curr = (*ppListHead);
	PSession prev = NULL;
	//
	while (TRUE) {
		if (curr == NULL) {
			break;
		}
		else if (curr->data == id) {
			break;
		}
		//
		prev = curr;
		curr = curr->next;
	}
	//
	if (curr) {
		if (prev == NULL) {													// curr is the first of the list
			(*ppListHead) = curr->next;
		}
		else {																	// curr not the first in the list
			prev->next = curr->next;
		}
		//
		curr->next = NULL;
	}
	//
	return curr;
}


/**
 * Initialize Session structure with ID
 * @param pSession Pointer to Session
 * @param id       ID
 */
void initializeSession(PSession pSession, int id) {
	pSession->pHeader								= NULL;
	pSession->data									= id;
	pSession->pRecordArray 						= NULL;				// Linked list holding sorted .csv files
	//
	initializeRecordArray(&(pSession->recordArraysTempOut[0]), 0);
	initializeRecordArray(&(pSession->recordArraysTempOut[1]), 0);
	//
	pSession->iCurrentOut						= 0;
	//
	pSession->next									= NULL;
}


/**
 * Clean up Session structure and all its record arrays
 * @param pSession Pointer to Session
 */
void cleanUpSession(PSession pSession) {
	if (pSession) {
		cleanUpRecordArrayList(&(pSession->pRecordArray));
		//
		cleanRecordArray(&(pSession->recordArraysTempOut[0]));
		cleanRecordArray(&(pSession->recordArraysTempOut[1]));
		//
		free(pSession);
	}
}