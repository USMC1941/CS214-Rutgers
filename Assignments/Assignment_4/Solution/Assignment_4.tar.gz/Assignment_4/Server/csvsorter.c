#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

#include "sortingkey.h"
#include "record.h"
#include "../Shared/global.h"
#include "../Shared/helper.h"
#include "recordarray.h"
#include "csvsorter.h"
#include "mergesort.h"
#include "tokenizer.h"


PFUNC_COMPARE_DATA pFuncCompare = compare;


/**
 * Perform sorting of a file as a buffer received from socket
 * @param  data   Contents of the file in buffer
 * @param  pKey   Sorting key
 * @param  length File length
 * @return        Pointer to sorted RecordArray
 */
RecordArray* doSorting(char* data, char* pKey, unsigned int length) {
	// To hold record array
	RecordArray* pRcdArray = (RecordArray*)malloc(sizeof(RecordArray));

	BUFFER buf;										// For holding the header line
	initBuffer(&(buf), 0);						// Buffer for holding header line

	if (initializeRecordArray(pRcdArray, SIZE_INITIAL) != SUCCESS) {
		cleanRecordArray(pRcdArray);
		free(pRcdArray);
		pRcdArray = NULL;
		//
		fprintf(stderr, "Could not initilize RecordArray\n");
	}
	else {
		unsigned int lenRemain = length;											// 1 for NULL. 1 for next read which will fail
		pRcdArray->pRaw = data;
		char* pRemain = pRcdArray->pRaw;
		//
		// Read the header and get the index for the sorting key
		char* pNewLine = NULL;
		if ((pNewLine = strchr(pRemain, '\n')) != NULL ) {					// Get header line used '\n' as delimeter
			*pNewLine = '\0';
			int len = pNewLine - pRemain + 1;									// Total length including NULL
			//
			resizeBuffer(&buf, len);
			strcpy(buf.data, pRemain);												// Keep an copy of the header line before tokenize
			//
			pRemain = pRemain + len;
			lenRemain = lenRemain - len;
			//
			if (getSortingKeyIndexFromHeaderLine(buf.data, pKey, &(pRcdArray->sKI))) {			// Get index of sorting key from header line
				cleanRecordArray(pRcdArray);
				free(pRcdArray);
				pRcdArray = NULL;
				//
				fprintf(stderr, "Could not parse sorting key\n");
			}
			else {
				pRcdArray->totalLength	= length;																// Total file size
				pRcdArray->headerLength	= len;																	// Including '\n' that convert to '\0'
				pRcdArray->dataLength	= length - len;														// Data length
				//
				// Read data line by line. Creates record and put them into array
				while ( (pNewLine = strchr(pRemain, '\n')) != NULL ) {									// Loop through records. Record delimeter is '\n'.
					*pNewLine = '\0';
					len = pNewLine - pRemain + 1;
					//
					//This block used twice
					{	resizeBuffer(&buf, len);
						strcpy(buf.data, pRemain);																	// Keep an copy of the header line before tokenize
						//
						Record* pRecord = getOneRecord(pRcdArray);
						//
						Record* pOut = setRecordData(pRecord, pRemain, buf.data, &(pRcdArray->sKI));
						//
						if (!pOut) {
							fprintf(stderr, "Could not create record\n");
						}
					}
					//This block used twice
					//
					pRemain = pRemain + len;
					lenRemain = lenRemain - len;
				}
				//
				if (lenRemain > 0) {																					// Handle last record with missing '\n'
					len = lenRemain + 1;
					//
					//This block used twice
					{	resizeBuffer(&buf, len);
						strcpy(buf.data, pRemain);																	// Keep an copy of the header line before tokenize
						//
						Record* pRecord = getOneRecord(pRcdArray);
						//
						Record* pOut = setRecordData(pRecord, pRemain, buf.data, &(pRcdArray->sKI));
						//
						if (!pOut) {
							fprintf(stderr, "Could not create record\n");
						}
					}
					//This block used twice
					//
					pRcdArray->dataLength = pRcdArray->dataLength + 1;										// Add 1 for the missing '\n'
				}
				//
				setPtrArray(pRcdArray);
				//
				mergeSort((void**)(pRcdArray->recPtrArray), 0, pRcdArray->iSize - 1, pFuncCompare);			// Do sorting
			}
		}
	}

	//Free buffer
	freeBuffer(&buf);

	return pRcdArray;
}
