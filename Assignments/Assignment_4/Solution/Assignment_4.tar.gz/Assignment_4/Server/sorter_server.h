#ifndef SORTER_SERVER_H
#define SORTER_SERVER_H


/**
 * Thread function to handle Socket connections
 * @param pInput Pointer to input Socket
 */
void* HandleTCPClient(void* pInput);


/**
 * Merge two sorted RecordArrays into one sorted
 * @param  p1     		First record array
 * @param  p2 			Second record arrasy
 * @param  pMerged    Merged recordarray
 */
void mergeTwo(PRecordArray p1, PRecordArray p2, PRecordArray pMerged);


#endif