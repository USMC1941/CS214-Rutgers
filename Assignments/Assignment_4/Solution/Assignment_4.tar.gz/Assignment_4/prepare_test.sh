#!/bin/sh

num_dir=$1
num_file=$2

clear

homedir=~/CS214/pa4
testdir=~/CS214/pa4/testdata
testoutdir=~/CS214/pa4/testout

subdir="$testdir"

filename="$homedir/movie_metadata.csv"
redir_stdout="$homedir/metadata.txt"


cd "$homedir"

rm -rf "$testdir"
rm -rf "$testoutdir"

mkdir "$testdir"
mkdir "$testoutdir"

if [[ "$num_dir" = 1 ]] && [[ "$num_file" > 0 ]]; then
	cd "$testdir"
	for (( i = 0; i < "$num_file"; i++ )); do
		cp  "$filename" "small_$i.csv";
	done
elif [[ "$num_dir" > 1 ]] && [[ "$num_file" > 0 ]]; then
	cd "$testdir"
	for (( i = 0; i < "$num_file"/"$num_dir"; i++ )); do
		cp  "$filename" "small_$i.csv";
	done
	#
	subdir="$testdir"
	for (( j = 0; j < "$num_dir" - 1; j++ )); do
		subdir="$subdir/a$j"
		mkdir "$subdir"
		#
		cd "$subdir"
		for (( i = 0; i < "$num_file"/"$num_dir"; i++ )); do
			cp  "$filename" "small_$i.csv";
		done
	done
else
	echo "Input Parameter Not Valid: $1 $2!"
	exit 0
fi
