#!/bin/sh

ipport=$1

host1=127.0.0.1
host2=128.6.13.177
host3=cp.cs.rutgers.edu

clientdir=Client
serverdir=Server

clear

cd "$serverdir"

#make

#./sorter_server "$ipport" &

cd "../$clientdir"

ls

make

./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c color &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c director_name &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c num_critic_for_reviews &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c duration &

sleep 60

./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c director_facebook_likes &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_3_facebook_likes &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_2_name &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_1_facebook_likes &

sleep 60

./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c gross &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c genres &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_1_name &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c movie_title &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c num_voted_users &

sleep 60

./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c cast_total_facebook_likes &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_3_name &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c facenumber_in_poster &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c plot_keywords &
./sorter_client -h "$host1" -p "$ipport" -d ../testdata -o ../testout -s 8 -c movie_imdb_link &

sleep 60

./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c num_user_for_reviews &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c language &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c country &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c content_rating &
./sorter_client -h "$host2" -p "$ipport" -d ../testdata -o ../testout -s 8 -c budget &

sleep 60

./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c title_year &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c actor_2_facebook_likes &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c imdb_score &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c aspect_ratio &
./sorter_client -h "$host3" -p "$ipport" -d ../testdata -o ../testout -s 8 -c movie_facebook_likes &
