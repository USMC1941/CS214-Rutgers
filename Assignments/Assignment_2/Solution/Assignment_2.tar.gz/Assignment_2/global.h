#ifndef GLOBAL_H
#define GLOBAL_H

#define TRUE							1
#define FALSE							0

#define SUCCESS						0
#define FAILURE						1

#define DELIMITER 					','
#define DBLQUOTE 						'\"'
#define DOT								'.'

#define SIZE_INITIAL					1024
#define SIZE_DELTA					1024

#define MAX_SORTING_KEY_COUNT		16
#define MAX_KEY_LENGTH				2048

#endif