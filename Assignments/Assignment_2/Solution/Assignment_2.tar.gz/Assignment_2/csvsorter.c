#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "global.h"
#include "helper.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "mergesort.h"
#include "csvsorter.h"
#include "tokenizer.h"


/**
 * Perform sorting with sortingKey
 * @param  inPath          Input file path
 * @param  inName          Input file name
 * @param  sortingKeyInput Comma delimited field list for sorting
 * @param  outPath         Output file path
 * @param  outName         Output file name
 * @return                 Success or failure
 */
int doSorting(const char* inPath, const char* inName, const char* sortingKeyInput, const char* outPath, const char* outName) {
	char inFullFileName[PATH_MAX + NAME_MAX + 1];
	char outFullFileName[PATH_MAX + NAME_MAX + 1];
	char sortingKeys[MAX_KEY_LENGTH];
	//
	strcpy(sortingKeys, sortingKeyInput);
	//
	if (inPath == NULL || strlen(inPath) == '\0') {
		strcpy(inFullFileName, inName);
	}
	else {
		strcpy(inFullFileName, inPath);
		strcat(inFullFileName, "/");
		strcat(inFullFileName, inName);
	}
	//
	if (outPath == NULL) {
		if (inPath == NULL || strlen(inPath) == '\0') {
			strcpy(outFullFileName, outName);
		}
		else {
			strcpy(outFullFileName, inPath);
			strcat(outFullFileName, "/");
			strcat(outFullFileName, outName);
		}
	}
	else {
		strcpy(outFullFileName, outPath);
		strcat(outFullFileName, "/");
		strcat(outFullFileName, outName);
	}

	// Variables
	PFUNC_COMPARE_DATA pFuncCompare = compare;

	// To hold key index
	SKeyIndex sKI;
	int iloop;
	for (iloop = 0; iloop < MAX_SORTING_KEY_COUNT; iloop++) {
		sKI.indexParse[iloop] = -1;
		sKI.idxType[iloop] = INDEX_TYPE_INTEGER;						// Initially set to integer. Change it later if necessary
		sKI.indexSort[iloop] = -1;
	}
	sKI.idxCount = 0;

	// Buffer for reading from file
	BUFFER readBuf;															// Buffer for reading
	initBuffer(&readBuf, 0);												// Memory to be allocated by getline. Will be freed at the end
	//
	BUFFER headerBuf;															// For holding the header line

	// To hold record array
	RecordArray rcdArray;
	rcdArray.pRecArray	= NULL;
	rcdArray.iCapacity		= 0;
	rcdArray.iSize			= 0;

	FILE *file = fopen(inFullFileName, "r");

	int outcome = 1;
	if (file == NULL) {
		printf("Could not open file for read\n");
	}
	else if (initializeRecordArray(&rcdArray, SIZE_INITIAL) != 0) {
		printf("Could not initilize Record array\n");
	}
	else {
		// Read the header and get the index for the sorting key
		if (getline(&(readBuf.data), &(readBuf.length), file) > 0 ) {
			stripOffNewline(&readBuf);
			//
			initBuffer(&headerBuf, readBuf.length);									// Buffer for holding header line
			strcpy(headerBuf.data, readBuf.data);										// Keep an copy of the header line before tokenize
			//
			if (getSortingKeyIndexFromHeaderLine(readBuf.data, sortingKeys, &sKI)) {
				//printf("Could not parse sorting key\n");
			}
			else {
				//

				//printSKeyIndex(&sKI);

				//
				// Read data line by line. Creates record and put them into array
				while (getline(&(readBuf.data), &(readBuf.length), file) > 0) {
					stripOffNewline(&readBuf);

					Record* pRecord = createRecord(readBuf.data, &sKI);
					if (pRecord) {
						insertOneRecord(&rcdArray, pRecord);
					}
					else {
						printf( "Could not create record\n");
					}
				}

				// Sort array according to Sorting Key
				mergeSort((void**)rcdArray.pRecArray, 0, rcdArray.iSize - 1, &sKI, pFuncCompare);

				// Output sorted records to file
				outcome = writeRecordArrayToFile(&headerBuf, &rcdArray, &sKI, outFullFileName);
			}
		}
		else {
			//printf("Could not read header line\n");
		}
	}

	if (file != NULL) {
		fclose(file);
	}

	// Clean up memory
	if (rcdArray.pRecArray != NULL) {
		cleanRecordArray(&rcdArray);
	}

	//Free buffer
	freeBuffer(&readBuf);
	freeBuffer(&headerBuf);

	// Return
	return outcome;
}


/**
 * Writes the data from the RecordArray into file
 * @param  pHeader      Field name line
 * @param  pRecordArray Array of records
 * @param  pSKI         Sorting key information
 * @param  outFileName  Output file name
 * @return              Success or failure
 */
int writeRecordArrayToFile(BUFFER* pHeader, RecordArray* pRecordArray, SKeyIndex* pSKI, const char* outFileName) {
	int outcome = 1;

	FILE *file = fopen(outFileName, "w");

	if (file != NULL) {
		// Print header
		fprintf(file, "%s\n", pHeader->data);																				// Print header line

		// Print all records
		int i;
		for (i = 0; i < pRecordArray->iSize; i++) {
			int j;
			for (j = 0; j < pSKI->idxCount; j++) {
				*((*(pRecordArray->pRecArray + i))->pSKeyTerm[j]) = (*(pRecordArray->pRecArray + i))->chHold[j];	// Put back the char set to '\0' for sorting key
			}
			//
			fprintf(file, "%s\n", (*(pRecordArray->pRecArray + i))->recordData);									// Print Records in a loop
		}

		outcome = 0;
	}
	else {
		printf( "Could not open file for writing.\n");
	}

	if (file != NULL) {
		// Close the file
		fclose(file);
	}

	return outcome;
}



// For debugging
void printSKeyIndex(SKeyIndex* pSKI) {
	printf("idxCount: %d\n", pSKI->idxCount);
	//
	int i;
	for(i = 0; i < MAX_SORTING_KEY_COUNT; i++) {
		printf("indexParse, idxType, indexSort: %d %d %d\n", pSKI->indexParse[i], pSKI->idxType[i], pSKI->indexSort[i]);
	}
}