#!/bin/sh

# Sort by all keys!

make

./sorter -c color,director_name,num_critic_for_reviews,duration,director_facebook_likes -d ./data -o /ilab/users/wjc98/CS214/pa2/output1
