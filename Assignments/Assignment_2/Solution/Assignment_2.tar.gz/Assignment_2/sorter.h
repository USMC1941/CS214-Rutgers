#ifndef SORTER_H
#define SORTER_H

// Structure to hold information about a process handling a subdirectory.
// This structure is also used to hold information about a process handling a directory.
typedef struct FolderNode {
	char						path[PATH_MAX + 1];		// The path of the folder under processing.
	int						fd[2];						// For pipe connecting parent and children folder. Pipe is created before fork() so parent and children have access to the shared pipe.
	pid_t						pid;							// PID of the process.
	//
	struct FolderNode* 	next;							// Linked list of all sub-folders
} FolderNode;

typedef FolderNode *PFolderNode;


/**
 * Clearns up FolderNode structure
 * @param ppFolderNode Input FolderNode structure.
 */
void cleanUpFolderNode(PFolderNode* ppFolderNode);


/**
 * Cleans up linked list of FolderNode structure which corresponds to all the subdirectories of one parent directory.
 * @param ppFolderNode Input linked list
 */
void cleanUpFolderNodeList(PFolderNode* ppFolderNode);


/**
 * Insert a FolderNode structure into a linked list
 * @param ppFolderNode   Linked list of FolderNodes for subdirectories.
 * @param pOneFolderNode Input FolderNode structure to be added
 */
void insertFolderNodeIntoList(PFolderNode* ppFolderNode, PFolderNode pOneFolderNode);


/**
 * Removes a FolderNode structure from the linked list
 * @param  ppFolderNode Linked list of FolderNodes for subdirectories
 * @param  pid          PID associated with the FolderNode
 * @return              Removed FolderNode
 */
PFolderNode  removeOneFromFolderNodeIntoList(PFolderNode* ppFolderNode, pid_t pid);


#endif