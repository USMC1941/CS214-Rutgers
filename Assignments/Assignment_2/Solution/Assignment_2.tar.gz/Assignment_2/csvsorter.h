#ifndef CSVSORTER_H
#define CSVSORTER_H


/**
 * Writes the data from the RecordArray into file
 * @param  pHeader      Field name line
 * @param  pRecordArray Array of records
 * @param  pSKI         Sorting key information
 * @param  outFileName  Output file name
 * @return              Success or failure
 */
int writeRecordArrayToFile(BUFFER* pHeader, RecordArray* pRecordArray, SKeyIndex* pSKI, const char* outFileName);


/**
 * Perform sorting with sortingKey
 * @param  inPath          Input file path
 * @param  inName          Input file name
 * @param  sortingKeyInput Comma delimited field list for sorting
 * @param  outPath         Output file path
 * @param  outName         Output file name
 * @return                 Success or failure
 */
int doSorting(const char* inPath, const char* inName, const char* sortingKeyInput, const char* outPath, const char* outName);


/**
 * [printSKeyIndex description]
 * @param pSKI [description]
*/
 
void printSKeyIndex(SKeyIndex* pSKI);

#endif