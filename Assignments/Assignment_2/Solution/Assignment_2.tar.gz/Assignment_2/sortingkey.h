#ifndef SORTINGKEY_H
#define SORTINGKEY_H


#define INDEX_TYPE_STRING			123			// Default. If data type neither float nor integer, it will be String
#define INDEX_TYPE_FLOAT			23				// Numbers. At least one of them is with decimal point
#define INDEX_TYPE_INTEGER			10				// Numbers. None with decimal point


// Index for the sortingkey
// Information for multiple keys are stored in thus struct.
typedef struct SKeyIndex {
	int indexParse[MAX_SORTING_KEY_COUNT];		// (index)the fields to sort. The order in the array are ascending in terms of the index. This is for parsing.
	int idxType[MAX_SORTING_KEY_COUNT];			// What type of index: STRING, FLOAT or INTEGER
	int indexSort[MAX_SORTING_KEY_COUNT];		// The order of sorting of the keys. Its values refers to the indexParse. This is for comparing records.
	int idxCount;										// How many sorting keys
} SKeyIndex;


/*
Gets the index for the sortingkey from the Header Line
*/
int getSortingKeyIndexFromHeaderLine(char* input, char* key, SKeyIndex* pSKI);


/**
 * Splits input keys array and puts them into a keyArray
 * @param keys      Array of input keys
 * @param MAX_COUNT Max number of keys to sort
 * @param delimiter Delimiter to split keys
 * @param keyArray  Array to return
 * @return    		  Number of keys
 */
int splitKeys(char* keys, int MAX_COUNT, char delimiter, char** keyArray);


/**
 * Check if token matches any key in keyArray
 * @param  keyArray Given array
 * @param  count    Number of keys in array
 * @param  token    Token to search for
 * @return          Index of key found in array
 */
int tokenMatchKey(char** keyArray, int count, char* token);


#endif



/*
-c f4,f2,f1

f1,f2,f3,f4,f5

indexParse->	0, 1, 3
indexSort->		3, 1, 0		



-c f4,f8,f1			(3)

f1,f2,f3,f4,f5

indexParse->	0, 3	(2)
indexSort->		3, 0		



*/