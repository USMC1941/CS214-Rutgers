#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "global.h"
#include "sortingkey.h"
#include "tokenizer.h"
#include "helper.h"


/*
Gets the index for the sortingkey from the Header Line
Return: Success or Failure
*/
int getSortingKeyIndexFromHeaderLine(char* input, char* key, SKeyIndex* pSKI) {
	int outcome = 1;

	// Check inputs
	if (pSKI == NULL || input == NULL ||key == NULL || input[0] == '\0' || key[0] == '\0') {
		return outcome;
	}

	// Get the list of keys
	char*	keysArray[MAX_SORTING_KEY_COUNT];
	int count = splitKeys(key, MAX_SORTING_KEY_COUNT, ',', keysArray);

	// Initilize to invalid index
	int keyCount = 0;
	//
	//
	//
	char* pToken;
	//
	Tokenizer tokenizer;
	initTokenizer(&tokenizer, input, DELIMITER, DBLQUOTE);
	//
	pToken = getNextToken(&tokenizer);
	int index = 0;																					// Token index
	// 
	while (pToken != NULL && keyCount < MAX_SORTING_KEY_COUNT) {
		int iIndex = tokenMatchKey(keysArray, count, pToken);
		if (iIndex >= 0) {																		
			pSKI->indexParse[keyCount] = index;
			pSKI->indexSort[iIndex] = keyCount;
			//
			keyCount++;
			//
			outcome = 0;
		}
		//
		pToken = getNextToken(&tokenizer);
		index++;
	}
	//
	pSKI->idxCount = keyCount;
	//
	return outcome;
}


/**
 * Splits input keys array and puts them into a keyArray
 * @param keys      Array of input keys
 * @param MAX_COUNT Max number of keys to sort
 * @param delimiter Delimiter to split keys
 * @param keyArray  Array to return
 * @return    		  Number of keys
 */
int splitKeys(char* keys, int MAX_COUNT, char delimiter, char** keyArray) {
	// From start till end of the string keys
	char* pIter 		= keys;
	char* pOneKey 		= pIter;
	//
	int 	indexCurr 	= 0;
	//
	while (indexCurr < MAX_COUNT) {
		if (*pIter == '\0') {
			*(keyArray + indexCurr) = pOneKey;
			//
			indexCurr++;
			// No more key
			break;
		}
		else if (*pIter == delimiter) {
			*(keyArray + indexCurr) = pOneKey;
			*pIter = '\0';
			//
			indexCurr++;
			// Go to next key
			pIter = pIter + 1;
			pOneKey = pIter;
		}
		else {
			pIter = pIter + 1;
		}
	}
	//
	return indexCurr;
}


/**
 * Check if token matches any key in keyArray
 * @param  keyArray Given array
 * @param  count    Number of keys in array
 * @param  token    Token to search for
 * @return          Index of key found in array
 */
int tokenMatchKey(char** keyArray, int count, char* token) {
	int outcome = -1;

	if (keyArray != NULL && token != NULL) {
		int i;
		for (i = 0; i < count; i++) {
			if (*(keyArray + i) != '\0') {
				if (strcicmp(*(keyArray + i), token) == 0) {
					outcome = i;
					break;
				}
			}
		}
	}
	//
	return outcome;
}