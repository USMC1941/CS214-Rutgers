#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>

#include "sorter.h"
#include "global.h"
#include "helper.h"
#include "sortingkey.h"
#include "record.h"
#include "recordarray.h"
#include "mergesort.h"
#include "csvsorter.h"
#include "tokenizer.h"


/*
Print PIDS of all child processes once in the initial process.

In all other processes, output the PID to stdout.
 */
int main(int argc, char* argv[]) {
	// Check for right number of inputs
	if (argc == 3 || argc == 5 || argc == 7) {
		// Good
	}
	else {
		printf("Usage Sorting: sorter -c sorting_key_field.\n");
		printf("Usage sorting: sorter -c comma_seperated_list.\n");
		printf("Usage Searching Directory: sorter -c sorting_key_field -d thisdir/thatdir.\n");
		printf("Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
		printf("Invalid number of parameters: %d!\n", argc);
		return 1;
	}

	// Parameters
	char* pSortingKey = NULL;		// -c
	char* pInDir		= NULL;		// -d
	char* pOutDir		= NULL;		// -o

	// Find parameters
	int i;
	for (i = 1; i < argc; i = i + 2) {
		char* pOption = argv[i];
		//
		if (strcmp(pOption, "-c") == 0) {
			if (pSortingKey == NULL) {
				pSortingKey = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage Sorting: sorter -c sorting_key_field.\n");
				fprintf(stderr, "Usage sorting: sorter -c comma_seperated_list.\n");
				return 1;
			}
		}
		else if (strcmp(pOption, "-d") == 0) {
			if (pInDir == NULL) {
				pInDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage Searching Directory: sorter -c sorting_key_field -d thisdir/thatdir.\n");
				return 1;
			}
		}
		else if (strcmp(pOption, "-o") == 0) {
			if (pOutDir == NULL) {
				pOutDir = argv[i + 1];
			}
			else {
				fprintf(stderr, "Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
				return 1;
			}
		}
		else {
			printf("Usage Sorting: sorter -c sorting_key_field.\n");
			printf("Usage sorting: sorter -c comma_seperated_list.\n");
			printf("Usage Searching Directory: sorter -c sorting_key_field -d thisdir/thatdir.\n");
			printf("Usage output to directory: sorter -c sorting_key_field -d thisdir -o thatdir.\n");
			printf("Invalid number of parameters: %d!\n", argc);
			return 1;
		}
	}

	// Default
	if (pInDir == NULL) {
		pInDir = ".";
	}

	// Create Directory if not exits
	if (pOutDir != NULL && strcmp(pOutDir, ".") != 0) {
	   mkdir(pOutDir, 0700);
	}






	/* StdOut:
		Initial PID: XXXXX
   	PIDS of all child processes: AAA,BBB,CCC,DDD,EEE,FFF, etc
   	Total number of processes: ZZZZZ
	*/

	char				buf[1024];								// Buffer for reading to and writing to pipe
	pid_t 			pid_child;								// Hold pid return from fork

	PFolderNode 	pFolderNode;							// For current folder
	PFolderNode 	pSubFolferListHead;					// Linked list of current folder's subfolders
	int 		 		isMaster;								// The only process not forked.
	int 				numberOfProcesses;					// 1 for self. Will add for children
	int 				depth;									// Master is 0

	// Initial for the master process
	pFolderNode = (PFolderNode)malloc(sizeof(FolderNode));
	strcpy(pFolderNode->path, pInDir);
	pFolderNode->pid = getpid();
  	pipe(pFolderNode->fd);									// No fork. Just for master
	pFolderNode->next	= NULL;								// Not in linked list
	//
	pSubFolferListHead 	= NULL;
	//
	isMaster 				= TRUE;
	numberOfProcesses 	= 1;
	depth 					= 0;

	printf("Initial PID: %d\n", pFolderNode->pid);
	printf("PIDS of all child processes: ");
	fflush(stdout);

	// This loop is for Indir and all subfolders
	while (TRUE) {
		pid_child = -1;																										// Reset for sub folder

		// Loop through all items in the folder
		DIR *dir;
		struct dirent *entry;
		//
		// Write PID for folder processing into pipe to go into metadata file
		if (isMaster) {
	     	sprintf(buf, "%*sPID %d started to process csv files in folder \"%s\"\n", depth * 3, "", getpid(), pFolderNode->path);
		}
		else {
   	  	sprintf(buf, "%*sPID %d forked from %d to handle sub-folder \"%s\"\n", depth * 3, "", getpid(), getppid(), pFolderNode->path);
		}
		write(pFolderNode->fd[1], buf, strlen(buf));
		//
		if (!(dir = opendir(pFolderNode->path))) {
			printf("PID %d Opening folder failed: %s\n", pFolderNode->pid, pFolderNode->path);
			printf("Oh dear, something went wrong with read()! %s\n", strerror(errno));
			return 1;
		}
		//
		while ((entry = readdir(dir)) != NULL) {
			if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {						// Current or parent directory
				// Ignore
			}
			else if (entry->d_type == DT_DIR) {																			// Directory
				PFolderNode pTemp = (PFolderNode)malloc(sizeof(FolderNode));
				strcpy(pTemp->path, pFolderNode->path);
				strcat(pTemp->path, "/");
				strcat(pTemp->path, entry->d_name);
				pTemp->pid = -1;
				pipe(pTemp->fd);
				pTemp->next	= NULL;
				//
				pid_child = fork();
				//
				if (pid_child == 0) {																						// Children
					printf("%d,", getpid());
					fflush(stdout);
					//
					// Clean up parent's PFolderNode
					cleanUpFolderNode(&pFolderNode);
					// Free SubFolder list from parent processFolder.
					cleanUpFolderNodeList(&pSubFolferListHead);
					//
					pFolderNode = pTemp;
					pTemp = NULL;
					pFolderNode->pid = getpid();
					close(pFolderNode->fd[0]);																				// Close pipe for reading from child
					//
					pSubFolferListHead 	= NULL;
					isMaster 				= FALSE;
					numberOfProcesses 	= 1;
					depth++;
					//
					break;
				}
				else {																											// Parent
      	      //close(pTemp->fd[1]);																					// Do not close parent side of pipe for input too early. Close right before read
					pTemp->pid = pid_child;
					//
					insertFolderNodeIntoList(&pSubFolferListHead, pTemp);
					//
					pTemp = NULL;
				}
			}
			else {																												// File: if (entry->d_type != DT_DIR)
				int lenName = strlen(entry->d_name);
				if (lenName > 4 && strcicmp(entry->d_name + lenName - 4, ".csv") == 0 && strstr(entry->d_name, "-sorted-") == NULL) {					// Check if file is .csv
					pid_child = fork();
					//
					if (pid_child == 0) {																					// Code for children
						printf("%d,", getpid());
						fflush(stdout);
						//
						char inPath[PATH_MAX + 1];
						strcpy(inPath, pFolderNode->path);
						//
						// Create output file name
						char outName[NAME_MAX + 1];
						strncpy(outName, entry->d_name, lenName - 4);
						outName[lenName - 4] = '\0';
						strcat(outName, "-sorted-");
						strncat(outName, pSortingKey, NAME_MAX - lenName - strlen("-sorted-"));
						strcat(outName, entry->d_name + lenName - 4);
						//
						// Clean up parent's PFolderNode
						cleanUpFolderNode(&pFolderNode);
						// Free SubFolder list from parent processFolder.
						cleanUpFolderNodeList(&pSubFolferListHead);
						//
						pFolderNode 			= NULL;
						pSubFolferListHead 	= NULL;
						isMaster 				= FALSE;
						numberOfProcesses 	= 0;
						depth						= -1;
						//
						// Perform sorting for a file
						doSorting(inPath, entry->d_name, pSortingKey, pOutDir, outName);
						//
						closedir(dir);
						_exit(0);
					}
					else {																											// Code for parent
						numberOfProcesses++;
						//
						sprintf(buf, "%*s- PID %d forked from %d to sort file \"%s\"\n", (depth + 1) * 3, "", pid_child, getpid(), entry->d_name);
	 					write(pFolderNode->fd[1], buf, strlen(buf));
					}
				}
			}
		}
		//
		closedir(dir);
		//
		if (pid_child == 0) {																								// Sub-folder
			// Sub-folder goes to beginning of while loop
			continue;
		}
		else {																													// Parent
			// Parent went through all items in directory already. Done
			break;
		}
	}
	//
	// Wait for all child processes to exit
	// Read metadata for sub-folders from pipe between parent and sub-folder child
	{	pid_t wpid;
		int status = 0;
		while ((wpid = wait(&status)) > 0) {																		// The parent waits for all the child processes
			// Find PID from linked list. Remove it.
			PFolderNode pTemp = removeOneFromFolderNodeIntoList(&pSubFolferListHead, wpid);
			//
			if (pTemp == NULL) {																							// File Process
				//printf("Processes Exit No FolderNode: %d %d %d\n", wpid, status, numberOfProcesses);
				//fflush(stdout);
				//
			}
			else {																											// Folder Process
				//
				int status_cde = WEXITSTATUS(status);
				numberOfProcesses = numberOfProcesses + status_cde;
				//
				//printf("Processes Exit: %d %d %d\n", wpid, status, numberOfProcesses);
				//fflush(stdout);
				//
				// Read metadata from sub-folder pipe and write it to parent's pipe
				int nbytes;
				//
				close(pTemp->fd[1]);																						// Close the writing end of the pipe before reading
				//
				while (TRUE) {
					nbytes = read(pTemp->fd[0], buf, sizeof(buf));
					//printf("Received string: %s %d\n", buf, nbytes);
					//
					if (nbytes > 0) {
						write(pFolderNode->fd[1], buf, nbytes);
					}
					else {
						break;
					}
				}
				//
		  		close(pTemp->fd[0]);																						// Close reading end of pipe - All are read
		  		//
		  		cleanUpFolderNode(&pTemp);
			}
		}
	}
	//
	//
	//
	// Close the pipe for writing
	if (isMaster) {																										// The process started from shell
		printf("\n");
		//
		close(pFolderNode->fd[1]);																						// Close the writing end of the pipe before reading
		//
		int nbytes;
		//
		FILE* fp = fopen("_metadata.txt", "w");																		// Open file for writing metadata to
		//
		while (TRUE) {
			nbytes = read(pFolderNode->fd[0], buf, sizeof(buf));
			//printf("Received string-----: %s %d\n", buf, nbytes);
			//
			if (nbytes > 0) {
				fwrite(buf, 1, nbytes, fp);
				fflush(fp);
				// write(pFolderNode->fd[1], buf, nbytes);
			}
			else {
				break;
			}
		}
		//
		fclose(fp);																											// Close metadata file
  		//
		printf("Total number of processes: %d\n", numberOfProcesses);
		//
  		close(pFolderNode->fd[0]);																						// Close reading end of pipe
  		cleanUpFolderNode(&pFolderNode);
	}
	else {																													// For process handling sub-folder, forked from parent
		close(pFolderNode->fd[1]);																						// Close the writing end of the pipe
  		cleanUpFolderNode(&pFolderNode);
  		//
		_exit(numberOfProcesses);
	}
	//
	return 0;
}


/**
 * Clearns up FolderNode structure
 * @param ppFolderNode Input FolderNode structure.
 */
void cleanUpFolderNode(PFolderNode* ppFolderNode) {
	if (ppFolderNode) {
		PFolderNode pFolderNode = *ppFolderNode;
		//
		if (pFolderNode) {
			close(pFolderNode->fd[0]);
			close(pFolderNode->fd[1]);
			free(pFolderNode);
		}
		//
		*ppFolderNode = NULL;
	}
}


/**
 * Cleans up linked list of FolderNode structure which corresponds to all the subdirectories of one parent directory.
 * @param ppFolderNode Input linked list
 */
void cleanUpFolderNodeList(PFolderNode* ppFolderNode) {
	if (ppFolderNode) {
		PFolderNode pListHead = *ppFolderNode;
		//
		if (pListHead) {
			PFolderNode pOneInList = pListHead;
			while (pOneInList) {
				PFolderNode pToBeFree = pOneInList;
				pOneInList = pOneInList->next;
				//
				close(pToBeFree->fd[0]);
				close(pToBeFree->fd[1]);
				free(pToBeFree);
			}
			pListHead = NULL;
		}
		//
		*ppFolderNode = NULL;
	}
}


/**
 * Insert a FolderNode structure into a linked list
 * @param ppFolderNode   Linked list of FolderNodes for subdirectories.
 * @param pOneFolderNode Input FolderNode structure to be added
 */
void insertFolderNodeIntoList(PFolderNode* ppFolderNode, PFolderNode pOneFolderNode) {
	if (ppFolderNode) {
		if (pOneFolderNode != NULL) {
			if (*ppFolderNode == NULL) {
				*ppFolderNode = pOneFolderNode;
				pOneFolderNode->next = NULL;
			}
			else {
				pOneFolderNode->next = *ppFolderNode;
				*ppFolderNode = pOneFolderNode;
			}
		}
	}
}


/**
 * Removes a FolderNode structure from the linked list
 * @param  ppFolderNode Linked list of FolderNodes for subdirectories
 * @param  pid          PID associated with the FolderNode
 * @return              Removed FolderNode
 */
PFolderNode removeOneFromFolderNodeIntoList(PFolderNode* ppFolderNode, pid_t pid) {
	PFolderNode pTemp = NULL;
	//
	if (ppFolderNode) {
		PFolderNode prev = NULL;
		//
		pTemp = *ppFolderNode;
		while (pTemp != NULL && pTemp->pid != pid) {
			prev = pTemp;
			pTemp = pTemp->next;
		}
		//
		// Remove from list
		if (pTemp) {
			if (prev == NULL) {
				*ppFolderNode = pTemp->next;
			}
			else {
				prev->next = pTemp->next;
			}
			//
			pTemp->next = NULL;
		}
	}
	//
	return pTemp;
}