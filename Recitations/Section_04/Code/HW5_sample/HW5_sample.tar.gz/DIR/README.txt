---------------- Description --------------------

In hw5_sample.c, I wrote a sample code for the ls
homework. I also write some instructions to your 
next assignment. 
To compile, please do
gcc -o test ./hw5_sample.c -g
then run
./test
It will recursively searching the files and directory
under current directory by default. 

enjoy

Hanxiong Chen
