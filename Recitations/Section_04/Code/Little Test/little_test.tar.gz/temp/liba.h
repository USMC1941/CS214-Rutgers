#ifndef _LIBA_H_
#define _LIBA_H_

#include "libb.h"
#include <stdio.h>
void func_liba();
void add_one();
#endif
