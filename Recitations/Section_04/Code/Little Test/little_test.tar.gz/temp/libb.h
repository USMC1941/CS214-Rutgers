#ifndef _LIBB_H_
#define _LIBB_H_

#include<stdio.h>

extern int global_var;
void func_libb();

#endif
