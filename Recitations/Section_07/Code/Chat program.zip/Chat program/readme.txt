To compile source code:  make
For server side:  ./server servername
For client side:  ./client localhost clientname cs214
where cs214 is the passwd